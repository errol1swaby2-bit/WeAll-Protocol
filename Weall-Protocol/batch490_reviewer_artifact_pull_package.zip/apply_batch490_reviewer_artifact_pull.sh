#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f "pyproject.toml" || ! -d "src/weall" ]]; then
  echo "ERROR: run this from the Weall-Protocol backend repo root." >&2
  exit 2
fi

PATCH_FILE="${1:-batch490_reviewer_artifact_pull.patch}"
if [[ ! -f "${PATCH_FILE}" ]]; then
  echo "ERROR: patch file not found: ${PATCH_FILE}" >&2
  echo "Copy batch490_reviewer_artifact_pull.patch into the repo root, or pass its path." >&2
  exit 2
fi

git apply --check "${PATCH_FILE}"
git apply "${PATCH_FILE}"
chmod +x scripts/reviewer_lan_genesis_rehearsal.sh scripts/reviewer_observer_rehearsal.sh

python3 -m py_compile src/weall/api/routes_public_parts/reviewer_artifacts.py
bash -n scripts/reviewer_lan_genesis_rehearsal.sh
bash -n scripts/reviewer_observer_rehearsal.sh

echo "OK: Batch 490 patch applied."
echo "Recommended validation:"
echo "  PYTHONPATH=src pytest -q tests/test_batch489_reviewer_disposable_genesis.py tests/test_batch490_reviewer_artifact_pull.py tests/test_batch488_reviewer_rehearsal_wrappers.py tests/test_external_observer_bundle_batch319.py tests/test_reviewer_public_tx_ingress_security.py"
