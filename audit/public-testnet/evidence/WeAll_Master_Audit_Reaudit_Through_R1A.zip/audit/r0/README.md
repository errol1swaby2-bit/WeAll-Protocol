# WeAll R0 — remediation evidence preservation

Baseline: `6d3d69234415d294936d99e819367cff589ced3d` ([commit](https://github.com/errol1swaby2-bit/WeAll-Protocol/commit/6d3d69234415d294936d99e819367cff589ced3d)).

Status: **R0 partial; public participatory testnet NO-GO.** No repository edits, commits, policy activation, or new production tests. This package is a local chat deliverable, not a repository artifact.

## Contents

- `master_register.tsv`: all 81 identifiers, prior Phase 6D labels, prior provisional severities, proposed remediation phase and individual acceptance objectives. 80 descriptions are carried forward, not independently recovered original narratives; TN-040 remains reserved.
- `candidate_register.tsv`: 8 separate tracking entries, including six Phase 6B candidates, zero-finality candidate and existing ADV-006 label. Possible overlaps are hypotheses, not merges.
- `evidence/`: retrieved-text transcriptions from `weall_phase5b_results.txt` and `weall_phase5c_results.txt`, not raw source archives. Hashes certify bundled bytes only. The originals and both Python harness files were located but could not be exported.
- `SHA256SUMS`: digest of each bundled payload (no claim of matching original file hash).

## Proposed primary phase allocation

| Phase | Findings | Scope |
|---|---:|---|
| R0 | 1 | Evidence recovery |
| R1 | 14 | Consensus foundation |
| R2 | 13 | Identity and authority |
| R3 | 3 | Constitutional justice |
| R4 | 11 | Democratic governance |
| R5 | 9 | Reputation and economics |
| R6 | 27 | Infrastructure and product |
| R7 | 3 | Independent revalidation |

All findings require R7 independent revalidation regardless of primary phase. Ordering does not authorize changes to constitutional policy.

## Evidence accounting

| Record | Checks | Passed | Failed | Status |
|---|---:|---:|---:|---|
| Phase 5A | 10 | 6 | 4 | Historical report only; original records unavailable |
| Phase 5B source checks | 22 | 14 | 8 | Retrieved result text, not rerun |
| Phase 5C source checks | 31 | 19 | 12 | Retrieved result text, not rerun |
| Phase 5B mathematical model | 5 | 5 | 0 | Retrieved result text; separate scope |
| Cumulative prior report | 167 | 119 | 48 | Unreconciled; do not add above rows again |

E0 hypothesis; E1 source confirmed; E2 isolated executable check; E3 signed production transaction-path reproduction; E4 independent multinode reproduction. The E2 designations in the register mean previously reported evidence, not fresh independent reproduction. Failure against a synthetic assertion may require adjudicating whether the assertion matches authorized policy.

## Closure contract

For every ID preserve baseline commit, original prose and source lines, affected invariants, actual effective deployment profile, reproduction command and dependencies, expected and actual results, patch commit, negative and positive regression results, evidence of deterministic replay where applicable, exact-head CI and independent production acceptance. Any P0/P1 severity change must record rationale and review. Duplicate findings retain original IDs and closure evidence. A dormant defect can be classified as unreachable only with enforceable profile gates and tests. No vulnerability closure is claimed.

## Missing records

Recover original TN-040, the original 60-invariant registry at this exact baseline (older registries are not substitutes), original 81 finding narratives/proofs, complete original 167-check evidence, raw Phase 5A/B/C outputs and harnesses, and other prior experimental artifacts. Do not infer missing invariant texts or counts. Preserve original artifacts byte-for-byte with SHA-256 once available.

## R1 intake

Begin verification of TN-052, TN-078, R0-C07 and R0-C06 using signed production-path tests at the frozen baseline; preserve original behavior before a patch. Verify canonical authority-effective-point policy before changing authorization. Expand to other R1 entries; no code change is authorized by this package.
