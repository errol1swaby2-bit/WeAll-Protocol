# Evidence and reconciliation index

Frozen baseline `6d3d69234415d294936d99e819367cff589ced3d`.

## Bundled evidence
| Artifact | Scope | Provenance |
|---|---|---|
| r0/master_register.tsv | 81 IDs | Prior R0, labels and proposed closure objectives |
| r0/candidate_register.tsv | 8 entries | Prior R0, possible overlaps and locators |
| r0/evidence/phase5b_retrieved_result.txt | 22 source checks (14 pass, 8 fail), separate 5 model pass | Retrieved text, original `weall_phase5b_results.txt` |
| r0/evidence/phase5c_retrieved_result.txt | 31 checks (19 pass, 12 fail) | Retrieved text, original `weall_phase5c_results.txt` |

## Prior reports, not raw evidence
- Phase 5A: 10 checks, 6 pass/4 fail (historical report only).
- Phase 5F: earlier conversation retrieval reports 30 checks, 28 pass/2 fail and TN-031 reproduced; original output and harness not recovered. Treat as unverified historical metadata, not a new reproduction or an evidence-level upgrade.
- Cumulative: 167 checks, 119 pass/48 fail, historically reported. Do not sum these subtotals into the cumulative count or assume the separate mathematical model is included. The records do not completely reconcile the total.
- Phase 6B: six cross-domain candidate descriptions, with exact-baseline source locators. Phase 6C: proposed consolidation into ten families; no formal merges or downgrades. Phase 6D: 80 labels recovered, TN-040 reserved. R0: 81 entries and eight separate tracked entries preserved.

## Source links cited in earlier audit
These links reference the frozen revision. They are indexed for follow-up rather than fresh source verification in this packaging turn.
- [net/gossip.py#L274-L331](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/net/gossip.py#L274-L331)
- [net/peer_list_store.py#L1-L141](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/net/peer_list_store.py#L1-L141)
- [runtime/apply/dispute.py#L3342-L3398](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/dispute.py#L3342-L3398)
- [runtime/apply/dispute.py#L837-L983](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/dispute.py#L837-L983)
- [runtime/apply/governance.py#L647-L735](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/governance.py#L647-L735)
- [runtime/apply/groups.py#L1478-L1574](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/groups.py#L1478-L1574)
- [runtime/apply/groups.py#L1755-L1947](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/groups.py#L1755-L1947)
- [runtime/apply/identity.py#L1258-L1367](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/identity.py#L1258-L1367)
- [runtime/apply/identity.py#L547-L591](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/identity.py#L547-L591)
- [runtime/apply/poh.py#L2220-L2280](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/apply/poh.py#L2220-L2280)
- [runtime/block_admission.py#L323-L477](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/block_admission.py#L323-L477)
- [runtime/block_replay.py#L690-L770](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/block_replay.py#L690-L770)
- [runtime/block_time_admission.py#L116-L197](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/block_time_admission.py#L116-L197)
- [runtime/block_time_admission.py#L72-L113](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/block_time_admission.py#L72-L113)
- [runtime/constitutional_clock.py#L172-L191](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/constitutional_clock.py#L172-L191)
- [runtime/domain_apply.py](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/domain_apply.py)
- [runtime/domain_dispatch.py](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/domain_dispatch.py)
- [runtime/helper_dispatch.py#L298-L322](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/helper_dispatch.py#L298-L322)
- [runtime/helper_merge.py#L243-L277](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/helper_merge.py#L243-L277)
- [runtime/helper_merge.py#L63-L75](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/helper_merge.py#L63-L75)
- [runtime/poh/state.py#L200-L279](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/poh/state.py#L200-L279)
- [runtime/reviewer_responsibilities.py#L164-L198](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/reviewer_responsibilities.py#L164-L198)
- [runtime/runtime_context.py](https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/runtime_context.py)

## Missing evidence and controls
- Original TN-040 title and evidence; do not assign this ID anew.
- Complete original 60-invariant registry; references to selected invariant IDs cannot substitute for full definitions.
- Original Phase 1–6 narrative records and complete 167-check logs; exact traceability for every TN ID is incomplete.
- Original Python harnesses `weall_phase5b_regressions.py` and `weall_phase5c_regressions.py`: indexed records located but export unavailable. Do not label the transcript text as runnable code or original file bytes.
- Production reachability, policy authorization and independent multinode validation remain open where specified. Preserve actual results, source hashes and environment metadata before closing.
- Archive SHA-256 hashes certify bundled bytes, not provenance or runtime correctness. Original R0 content retained under r0/ with its original checksums.
