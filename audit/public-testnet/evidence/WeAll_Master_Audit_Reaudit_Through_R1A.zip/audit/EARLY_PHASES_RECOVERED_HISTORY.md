# Early audit phases — recovered historical descriptions

Baseline `6d3d69234415d294936d99e819367cff589ced3d`. These are retrieved conversation-history summaries, **not** original reports or source-verification in this packaging turn. Do not use them as a substitute for the missing transcripts. November 19–20 2026.

| Phase | Available historical material |
|---|---|
| 0 | Initial indexing: 2,873 tracked files; 236 canonical transaction types; 295 backend source files; 1,170 backend tests; 143 frontend files; 125 deployment/release files. Initial 15 blockers and 8 findings TN-001–008; architecture and deployment checklist reported; NO-GO. |
| 1A | Transaction-admission tracing; observer forwarding (TN-003), Genesis ML-DSA key incompatibility (32-byte vs 1,952-byte; 64-hex generator, reported TN-009), registration verification ordering (TN-010). |
| 1B | Consensus phases and quorum; first canonical solo finality (TN-011); zero Genesis timestamp and clock enforcement (TN-012); observer/validator replay divergence (TN-013); procedural-time regression (TN-014). |
| 1C | Raw session bearer in signed history (TN-015); predictable reviewer selection and public-testnet compatibility mode (TN-016); scalar reputation remains operative (TN-017); legacy verification-tier inconsistency (TN-018); recovery protections present. 18 findings reported. |
| 1D | Attributable ballots (TN-019); automatic bans bypass severe-sanction safeguards (TN-020); public-testnet governance/ballot profile discrepancy (TN-021); proposal-defined thresholds (TN-022); tally inconsistency (TN-023); group membership removal due process (TN-024). 24 findings reported. |
| 1E | CID/digest conflicts (TN-025); retained replacement digest (TN-026); storage capacity bypass (TN-027); premature deletion attestations (TN-028); aggregate isolation gaps (TN-029); untrusted MIME (TN-030). |
| 1F | Economic activation (TN-031); transfer identifier collision (TN-032); reward conservation (TN-033); readiness reporting (TN-034); storage payout (TN-035); supply reconciliation (TN-036). 36 findings: 20 P0, 16 P1. |
| 2 | 60 invariants historically reported; original definitions not recovered. |
| 3–4 | Adversarial and divergence analysis reported; complete original phase narratives and results not accessible. |
| 5A | Historical summary: 10 checks, 6 passed, 4 failed. Original harness/log missing. |
| 5B | 22 source/predicate checks and 5 separate model checks now preserved with text-extracted harness and result log. |
| 5C | 31 checks now preserved with text-extracted harness and result log. |
| 5D–5E | Original reports and execution records not recovered. |
| 5F | Historical summary: 30 checks, 28 passed, 2 failed; TN-031 reproduced at predicate level, TN-043 partial synchronization commitment source-confirmed. Original execution record missing. |
| 6A | Reverse authority tracing reported complete; original detailed report missing. |
| 6B | Detailed report pasted by user, transcribed in this archive. |
| 6C–6D | Current conversation reports accessible; detailed reconstruction and original R0 artifacts in this archive. |

## Monetary policy context from Phase 1F
The visible fragment of the Phase 1F report states 21,000,000 WCN maximum supply, zero Genesis balances, eight decimals, 20-second target blocks, ten-minute issuance interval, 30 blocks per issuance epoch and initial 100 WCN epoch issuance. The remainder of the original table and tracing is missing. Later conversation history refers to changed tokenomics targets; these are not silently merged with the pinned implementation or treated as deployed policy. The Phase 5B harness and saved logs preserve their own model inputs.

## Cumulative counts
81 provisional IDs, 21 P0 and 60 P1, 60 invariants, 167 previously reported checks (119 pass, 48 fail), no closures. Original Phase 0–5 reports remain required to verify all entries, especially TN-040, and reconstruct the complete invariant list. Phase count subtotals must not be combined without reconciling exactly which checks were counted and whether model checks were included.
