# Phase 6B — Recursive cross-domain failure analysis

Baseline: `6d3d69234415d294936d99e819367cff589ced3d`. Audit mode: strictly read-only.

**Provenance:** detailed plain-text transcription of the Phase 6B report pasted by the user in the current conversation. Interactive graphics are transcribed into text; Markdown links are retained through the source index. This is not a new reproduction.

This phase examines vulnerabilities that emerge not from individual components malfunctioning, but from different components operating under incompatible definitions of authority.

## 1. Human verification and governance eligibility

Source-confirmed inconsistency — pending production reachability verification.

WeAll includes a canonical function, `effective_poh_tier()`, that determines a participant's actual verification status. It distinguishes active, expired, revoked, suspended and challenged identities. However, the governance electorate construction functions read the account's legacy `poh_tier` field directly.

| Verification condition | Effective PoH tier | Potential legacy tier |
|---|---:|---:|
| Active Tier 2 | 2 | 2 |
| Expired Tier 2 | 1 | 2 |
| Suspended | 0 | 2 |
| Under challenge | 0 | 2 |
| Revoked | 0 | 0 |

The legacy value can therefore overstate effective authority when status and tier are not fully synchronized. The normal expiration scheduler updates the mirrored account record, mitigating part of this concern. Existing electorate snapshots and other status transitions still require separate verification. Affected invariants: INV-019, INV-027 and INV-029.

Sources: `runtime/poh/state.py:200–279`; `runtime/apply/governance.py:647–735`.

## 2. Dispute accountability and reviewer eligibility

Candidate defect — Accountability enforcement inconsistency.

When a juror fails to complete an assigned dispute vote, `_record_dispute_juror_accountability()` records the failure and modifies the participant's account-level eligibility. The shared reviewer-lane authorization function, however, evaluates a different collection of records.

Accountability subsystem: dispute juror eligibility = False (missed voting obligation recorded). Reviewer authorization: reviewer lane active = True (existing role record remains active). A similar inconsistency exists within Proof-of-Humanity reviewer accountability.

| Subsystem | Accountability mutation |
|---|---|
| Dispute resolution | `dispute_juror_eligible = False` |
| Proof-of-Humanity | `poh_reviewer_eligible = False` |
| Reviewer responsibilities | Evaluates role and lane records |
| Reputation role activation | Evaluates separate versioned eligibility rules |

The shared lane predicate does not independently inspect either of those account-level accountability flags. This creates a potential discrepancy between a sanction being recorded and that sanction becoming operationally effective. The appropriate security requirement is that a participant cannot continue exercising an institutional responsibility after a legitimate suspension has taken effect.

Sources: `runtime/apply/dispute.py:3342–3398`; `runtime/reviewer_responsibilities.py:164–198`; `runtime/apply/poh.py:2220–2280`.

## 3. Dispute panel contraction

Candidate defect — Constitutional quorum degradation.

The dispute resolution subsystem recalculates its required voting threshold using the currently eligible reviewer population. Under the existing version-one policy, reductions in eligible panel membership can consequently reduce the required quorum.

Illustrative seven-juror panel: remaining eligible jurors 7; dynamic quorum 5; original panel quorum 5. Threshold comparison derived from the current integer quorum function. Quorum alone does not establish verdict approval.

The source already contains a stronger version-two protection that preserves the original panel threshold and prevents automatic resolution when the lawful panel becomes incomplete. However, this protection is explicitly dormant pending a separately authorized activation. That confirms an important distinction between implemented safeguards and operational safeguards. A complete adversarial reproduction involving reviewer withdrawal, panel replacement and subsequent verdict execution remains outstanding.

Source: `runtime/apply/dispute.py:837–983`.

## 4. Emissary elections and treasury authority

Potential high-impact candidate defect — Candidate eligibility.

The group emissary election implementation has an explicit protection against seating candidates when no valid ballots were submitted. The newer election policy also enforces a frozen participation quorum. However, candidate eligibility is a separate concern.

The election creation handler normalizes the supplied candidate identifiers. The finalization handler retrieves those identifiers, calculates STV winners and assigns the resulting individuals as group and treasury signers. I did not locate an independent candidate eligibility check in either inspected handler.

Candidate registration (identifiers supplied) → election (participation quorum enforced) → STV calculation (winning candidates determined) → institutional seating (group emissaries replaced) → treasury authority (treasury signers replaced).

| Candidate condition | Enforcement established? |
|---|---|
| Registered account | Not established at seating |
| Current group membership | Not established at seating |
| Active Tier-2 verification | Not established at seating |
| Current reputation eligibility | Not established at seating |
| Account suspended during election | Not established at seating |

Subsequent signer authorization checks provide additional protections, including effective PoH validation. Consequently, seating an ineligible individual does not necessarily grant them usable spending authority. Nevertheless, an election that replaces legitimate signers with unavailable or ineligible identities could potentially leave a treasury unable to reach its required signature threshold. This is both an institutional integrity concern and an availability concern.

Sources: `runtime/apply/groups.py:1478–1574`, `1755–1947`.

## 5. Account recovery and consensus authority

The account recovery implementation correctly performs extensive credential replacement.

Established recovery behavior: previous transaction-signing keys revoked; previous registered devices revoked; previous sessions revoked; new account-signing authority installed; new offline recovery authority installed; authority generation incremented; temporary post-recovery restrictions established.

Cross-domain authority still requiring verification: validator consensus keys; existing operator authority; previously assigned reviewer responsibilities; pending treasury signature obligations.

Account recovery replaces account-level authority, but consensus and institutional roles maintain additional authority records. These records may intentionally use separate keys and lifecycle requirements. Automatically removing validators during account recovery could itself compromise consensus availability. The outstanding requirement is therefore not unconditional revocation of every responsibility. It is an explicit, safe transition policy for each responsibility affected by an account recovery.

Source: `runtime/apply/identity.py:1258–1367`.

## 6. Intra-block authorization consistency

Potential critical candidate defect — Stale transaction authorization.

Block admission performs signature, nonce and eligibility checks before sequential transaction execution begins. The admission function adjusts each signer's nonce cursor to account for preceding transactions, but does not reconstruct every preceding state mutation. This creates a potentially significant boundary involving transactions that change authorization within a block.

Initial ledger: signing key active. Block admission: both transactions evaluated against the initial signing authority. Transaction 1: signing key revoked. Transaction 2: previously admitted transaction reaches its execution handler. Does the second transaction revalidate the modified signing authority?

The inspected execution loop does not visibly repeat the complete signature-admission process before each domain mutation. This warrants particularly careful investigation across key revocation, account restrictions, role suspension and treasury signer replacement. Both block construction and follower replay use the pre-execution admission mechanism. Consequently, this could represent a deterministic authorization failure rather than a disagreement between honest nodes. The exact intended effective point of revocation must also be established: immediate transaction ordering or the subsequent block boundary. No signed reproduction was performed.

Sources: `runtime/block_admission.py:323–477`; `runtime/apply/identity.py:547–591`; `runtime/block_replay.py:690–770`.

## 7. Cross-domain risk matrix

Potential consequences of inconsistent authority propagation:

| | Identity | Justice | Governance | Consensus | Economics |
|---|---|---|---|---|---|
| Identity | H | H | H | H | H |
| Reputation | M | H | H | M | M |
| Justice | H | H | M | M | L |
| Governance | M | M | H | H | H |
| Consensus | H | H | H | H | H |
| Recovery | H | M | M | H | H |

H = high, M = moderate, L = low. Qualitative architectural impact assessment, not measured exploit probabilities.

The recurring architectural weakness is fragmented authority representation: several subsystems maintain separate records describing whether an individual possesses a particular responsibility. The existence of those separate records is not inherently problematic. The danger arises when their respective state transitions and authorization predicates disagree.

## 8. Cumulative audit status

81 provisional numbered findings; 60 protocol invariants; 21 P0; 60 P1; 167 previously reported experimental checks (119 passed, 48 failed); 0 resolved. The additional candidate defects were not incorporated into the numbered register before consolidation to avoid duplication.

## 9. Remaining audit work

Phase 0 codebase indexing; Phase 1 execution tracing; Phase 2 invariant extraction; Phase 3 adversarial analysis; Phase 4 divergence analysis; Phase 5 executable reproduction; Phase 6A reverse authority tracing; Phase 6B cross-domain failure analysis; next Phase 6C consolidation and severity reassessment; Phase 6D completeness and final report.

## Audit limitations

This segment consisted exclusively of static source inspection. No additional executable tests were performed, and the constitutional specification documents were not reopened. The qualitative impact classifications are provisional audit judgments. No repository files, configurations, commits or operational infrastructure were modified. Public testnet deployment verdict: NO-GO.
