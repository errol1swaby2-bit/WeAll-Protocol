# WeAll Public Testnet Audit — all findings through R0

Baseline `6d3d69234415d294936d99e819367cff589ced3d` | cutoff 2026-11-20 | retrospective consolidation; no new tests or code changes.

## Executive assessment
Public participatory testnet deployment remains **NO-GO**. 81 provisional numbered findings (21 P0, 60 P1); 80 labels recovered; 8 separate tracking entries; none formally closed. The findings do not represent 81 proven production exploits. P0/P1 reflect previously reported provisional classifications; the eighth separate tracking entry is existing ADV-006, not a new numbered finding. Original full narratives were not recovered for every finding. This document restates the R0 register, not reconstructed verbatim phase transcripts.

Evidence levels: E0 hypothesis; E1 static source confirmation; E2 isolated executable reproduction; E3 production transaction-path reproduction; E4 independent multinode reproduction. Severity and evidence strength are separate. Closure objectives below are proposed, not ratified policy.

## Numbered findings — P0

### TN-001 — Unsigned seed registry
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject unauthenticated discovery records; verify independent peer discovery.

### TN-002 — Cloudflare registry verification
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify signatures and chain binding at deployed registry boundary.

### TN-003 — Observer forwarding boundary
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove observer cannot gain write or consensus authority through forwarding.

### TN-004 — Controlled-testnet mechanism gates
**P0 · OPEN · R7**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify production configuration cannot enable unsafe controlled-testnet paths.

### TN-006 — Deployment configuration
**P0 · OPEN · R7**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject unsafe or conflicting production settings before service starts.

### TN-009 — Genesis cryptographic authority
**P0 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove exact genesis authority, credential binding and expiry on independent nodes.

### TN-011 — First canonical solo finality
**P0 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify initial finality proof and transition to multi-validator epochs.

### TN-012 — Constitutional clock enforcement
**P0 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject off-slot or unauthorized time advances at build and replay boundaries.

### TN-013 — Role-dependent block replay
**P0 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify equal block replay results across node roles.

### TN-015 — Session bearer exposure in blockchain history
**P0 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Demonstrate public history contains no reusable bearer credentials.

### TN-016 — Human uniqueness and reviewer selection
**P0 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Demonstrate uniqueness constraints and authorized reviewer assignment under adversarial cases.

### TN-019 — Ballot confidentiality
**P0 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify public ledger and API cannot reveal protected voter-choice linkage under specified threat model.

### TN-020 — Automatic bans circumventing severe-sanction safeguards
**P0 · OPEN · R3**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove severe sanctions require applicable panel, appeal and enforcement authority.

### TN-021 — Public testnet governance configuration
**P0 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify enabled testnet governance conforms to authorized configuration.

### TN-022 — Proposal-defined electoral thresholds
**P0 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject thresholds outside authorized constitutional bounds.

### TN-025 — Media integrity and conflicting CID declarations
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject inconsistent commitments; verify returned bytes against expected CID.

### TN-027 — Storage capacity accounting bypass
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Enforce quotas across all admitted storage paths.

### TN-028 — Evidence deletion attestation integrity
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Require verifiable evidence deletion attestation and authorized provenance.

### TN-030 — Untrusted media MIME types
**P0 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Ensure active or unsafe media is rejected or rendered within safe isolation.

### TN-031 — Economic activation restrictions
**P0 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove economic mutations remain disabled until authorized activation conditions hold.

### TN-053 — Raw session credentials in canonical transactions
**P0 · OPEN · R2**

Evidence: E2 reported in Phase 5A history; original output and harness unavailable.

Proposed closure: Reject reusable credentials at canonical transaction and history boundaries.


## Numbered findings — P1

### TN-005 — Artifact regeneration
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Rebuild committed derivatives from clean checkout and compare digests.

### TN-007 — Frontend deployment validation
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Validate deployed build and real browser API journey at pinned revision.

### TN-008 — Independent acceptance evidence
**P1 · OPEN · R7**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Repeat fresh-clone acceptance with independent operators and retain logs.

### TN-010 — Registration resource protection
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Establish bounded unauthenticated registration and rejection without resource exhaustion.

### TN-014 — Premature procedural time progression
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify procedures cannot advance on unfinalized height.

### TN-017 — Reputation Matrix authorization discrepancy
**P1 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove reputation mutations require canonical provenance and authority.

### TN-018 — Verification status consistency
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Compare effective PoH, mirrors, eligibility transitions and snapshots across domains.

### TN-023 — Inconsistent tally criteria
**P1 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify identical outcomes across equivalent tally and resolution paths.

### TN-024 — Group membership due process
**P1 · OPEN · R3**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Ensure membership discipline requires applicable notice, review and authorization.

### TN-026 — Media replacement invalidates integrity metadata
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Ensure replacements update or invalidate metadata atomically.

### TN-029 — Incomplete storage resource isolation
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Demonstrate tenant/resource isolation under contention.

### TN-032 — Transfer identifier collision
**P1 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify domain separation, uniqueness and idempotence of transfer identifiers.

### TN-033 — Reward distribution conservation
**P1 · OPEN · R5**

Evidence: E2 reported; retrieved Phase 5B result text: R21,R22.

Proposed closure: Reject nonconserving distributions; validate scheduler provenance and atomicity.

### TN-034 — Economic readiness reporting
**P1 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject placeholder policies and incomplete activation requirements.

### TN-035 — Storage compensation settlement
**P1 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify compensation only for authorized measured settlement, exactly once.

### TN-036 — Monetary supply reconciliation
**P1 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reconcile issued supply, balances, burns if authorized, and all monetary states.

### TN-037 — Peer-store saturation
**P1 · OPEN · R6**

Evidence: E2 reported; retrieved Phase 5C result text: peer store saturation.

Proposed closure: Verify bounded peer rotation and discovery under saturated hostile fixtures.

### TN-038 — Multi-hop peer discovery failure
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Demonstrate safe discovery and synchronization beyond bootstrap peers.

### TN-039 — Peer advertisement temporal validation
**P1 · OPEN · R6**

Evidence: E2 reported; retrieved Phase 5C result text: zero start/expiry.

Proposed closure: Validate time bounds and signatures, including missing and zero values.

### TN-040 — Original description not recovered
**P1 · OPEN — evidence missing · R0**

Evidence: Identifier only; prior P1 classification inferred from counts.

Proposed closure: Recover original finding narrative and evidence; never reuse this identifier.

### TN-041 — Peer persistence failure reporting
**P1 · OPEN · R6**

Evidence: E2 reported; retrieved Phase 5C result text: persistence failure.

Proposed closure: Surface write failures without falsely reporting durability.

### TN-042 — Historical transaction visibility after checkpoint recovery
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify required historical visibility and explicit pruning behavior after recovery.

### TN-043 — Synchronization verification after durable commitment
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject unauthenticated history before durable commitment or prove safe rollback.

### TN-044 — Intergenerational historical preservation
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify required archival history survives multi-generation recovery.

### TN-045 — Incorrect recovery agreement calculation
**P1 · OPEN · R6**

Evidence: E2 reported in Phase 5A history; original output and harness unavailable.

Proposed closure: Verify agreement formula and boundary cases against authorized policy.

### TN-046 — Incomplete historical integrity verification at startup
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject or quarantine corrupted history before serving authoritative state.

### TN-047 — Helper receipt semantic verification
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject validly signed but semantically invalid helper outputs.

### TN-048 — Execution manifest authentication
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify authenticated canonical execution manifest and replay binding.

### TN-049 — Helper certificate recovery
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify restart recovery and receipt/certificate replay safety.

### TN-050 — Helper timeout enforcement
**P1 · OPEN · R1**

Evidence: E2 reported; retrieved Phase 5C result text: missing timestamp.

Proposed closure: Verify missing and boundary timestamps cannot bypass timeout policy.

### TN-051 — Inconsistent ledger references
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify canonical ledger references across execution, restart and replay.

### TN-052 — Hierarchical state conflict detection
**P1 · OPEN · R1**

Evidence: E2 reported; retrieved Phase 5C result text: hierarchical and alias overlaps.

Proposed closure: Detect normalized-path and ancestor/descendant hazards; prove serial equivalence.

### TN-054 — Device revocation leaves sessions active
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove revoked device sessions cannot authenticate after effective revocation.

### TN-055 — Unbounded session lifetime
**P1 · OPEN · R2**

Evidence: E2 reported in Phase 5A history; original output and harness unavailable.

Proposed closure: Enforce bounded expiration against canonical session policy.

### TN-056 — Recovery-induced account denial of service
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove only legitimate recovery can restrict accounts; demonstrate restoration path.

### TN-057 — Failed recovery reversal can leave account locked
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify recovery failure is atomic and restoration cannot strand accounts.

### TN-058 — Encrypted evidence intake validation
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Validate encrypted evidence structure, binding and safe failure paths.

### TN-059 — Premature PoH submission reconciliation
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Require canonical evidence and submission confirmation before completion.

### TN-060 — Incorrect reviewer-readiness representation
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Match displayed readiness to effective reviewer entitlement.

### TN-061 — Inconsistent transaction confirmation requirements
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Require consistent finality confirmation for frontend transaction lifecycles.

### TN-062 — Observer queue discards unresolved transactions
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Retain unresolved transactions or expose explicit terminal disposition.

### TN-063 — Upstream transaction rejection not reconciled
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Propagate upstream rejection and reconcile local status.

### TN-064 — Unsafe automatic retry
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify retry idempotence and ambiguity handling.

### TN-065 — Inconsistent node identity
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify canonical node identity across API, transport and persistence.

### TN-066 — Insufficient quorum bounds
**P1 · OPEN · R4**

Evidence: E2 reported; retrieved Phase 5B result text: R12.

Proposed closure: Prove authorized minimum quorum at every proposal creation and resolution boundary.

### TN-067 — Constitutional deliberation can be abbreviated
**P1 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Enforce minimum authorized deliberation windows against finalized time.

### TN-068 — Incomplete historical proposal version commitments
**P1 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Bind proposal semantics and decision evidence to immutable historical versions.

### TN-069 — Incorrect constitutional version ordering
**P1 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify canonical amendment ordering, replay and activation.

### TN-070 — Incorrect ballot-context commitments
**P1 · OPEN · R4**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Bind ballot authorization to correct election, scope, version and context.

### TN-071 — Inconsistent governance approval semantics
**P1 · OPEN · R4**

Evidence: E2 reported; retrieved Phase 5B result text: R16.

Proposed closure: Require equivalent early and deadline rules for each authorized proposal type.

### TN-072 — Multi-option expiration counting
**P1 · OPEN · R4**

Evidence: E2 reported; retrieved Phase 5B result text: R14.

Proposed closure: Verify multi-option tally and expiration semantics against authorized rules.

### TN-073 — Fraudulent storage proof
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject fabricated possession/availability proofs under specified threat model.

### TN-074 — Receipt validation
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject malformed, misbound and replayed receipts at all applicable boundaries.

### TN-075 — Reputation reversal
**P1 · OPEN · R5**

Evidence: E2 reported; retrieved Phase 5B result text: R25,R26.

Proposed closure: Demonstrate deterministic correction with saturation and intervening events.

### TN-076 — Predictable dispute panels
**P1 · OPEN · R3**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Verify selection resists applicable manipulation and conflict-of-interest threats.

### TN-077 — Unbounded rejected-certificate accounting
**P1 · OPEN · R1**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Bound rejection accounting without compromising safety or diagnostics.

### TN-078 — Local manifest precedence over canonical clock policy
**P1 · OPEN · R1**

Evidence: E2 reported; retrieved Phase 5C result text: manifest precedence.

Proposed closure: Reject conflicting configuration or enforce canonical agreement across nodes.

### TN-079 — Ambiguous account-recovery identifiers
**P1 · OPEN · R2**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Prove identity resolution is unique and unauthorized recovery cannot target aliases.

### TN-080 — Reversal requests escape expiration
**P1 · OPEN · R5**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Enforce authorized reversal deadlines and reject unauthorized late mutation.

### TN-081 — Malformed upstream confirmation acceptance
**P1 · OPEN · R6**

Evidence: Prior Phase 6D label only; original narrative and proof pending retrieval.

Proposed closure: Reject malformed, misbound or unauthenticated confirmations.

## Cross-domain and additional candidates

These remain separate from the 81 numbered entries. Possible overlaps are not adjudicated duplicates. Source observations below derive from Phases 6B–6D and the retrieved regression records. Production reachability remains unproven unless specifically stated.

### R0-C01 — Effective PoH versus legacy electorate

Canonical `effective_poh_tier()` distinguishes status and expiry; governance electorate construction reads mirrored `poh_tier` with account flags. The v1 emissary election electorate also imports this governance predicate. Expiration synchronization mitigates some cases. Existing snapshots and suspended/challenged status transitions require verification. Affected invariants were previously reported as INV-019, INV-027, INV-029; their full original definitions remain missing.

Possible overlap: TN-018; TN-021.

Source/evidence: runtime/poh/state.py#L200-L279; runtime/apply/governance.py#L647-L735; runtime/apply/groups.py#L1478-L1574.

Proposed closure: Signed status transitions and snapshot semantics; verify actual voter authorization.

### R0-C02 — Reviewer sanctions not reflected in lane eligibility

Dispute and PoH accountability set `dispute_juror_eligible` / `poh_reviewer_eligible` false; the shared lane predicate evaluates role/lane records instead. The PoH handler also writes a separate suspended-reviewers record. Need to prove whether assignment/action handlers enforce these flags independently. Legitimate suspension must be effective without involuntarily binding reviewers to service.

Possible overlap: TN-017; TN-020.

Source/evidence: runtime/reviewer_responsibilities.py#L164-L198; runtime/apply/dispute.py#L3342-L3398; runtime/apply/poh.py#L2220-L2280.

Proposed closure: Apply legitimate accountability action and verify subsequent assignment and vote authorization.

### R0-C03 — Dispute quorum contraction

V1 dynamic quorum can contract with the eligible reviewer population. V2 initial-panel protection preserves the original threshold and checks panel completeness; source notes no current governance activation path. Seven original jurors have an illustrative 5-vote threshold; loss of eligible reviewers can reduce the V1 threshold. Do not infer verdict approval from quorum alone. Verify appeal/replacement transitions separately; never activate the dormant policy as an audit action.

Possible overlap: TN-020; TN-076.

Source/evidence: runtime/apply/dispute.py#L837-L983.

Proposed closure: Compare v1 and v2 for withdrawal, replacement, incomplete panels, and resolution; no policy activation implied.

### R0-C04 — Emissary seating eligibility and treasury availability

Election creation normalizes candidate IDs, and finalization evaluates valid ballots and versioned quorum, calculates STV winners and updates emissaries and group/treasury signers. No independent candidate eligibility check was located in these handlers. Finalization also fills fewer than five winners from remaining candidates. Downstream signer checks may prevent spending while leaving signer threshold unavailable. Need to establish valid membership, account and eligibility requirements at authorized lifecycle points.

Possible overlap: TN-021; TN-024.

Source/evidence: runtime/apply/groups.py#L1478-L1574; runtime/apply/groups.py#L1755-L1947.

Proposed closure: Verify eligible candidates at authorized lifecycle points; verify valid signer threshold after seating.

### R0-C05 — Account recovery across institutional authority

Recovery revokes prior signing keys, devices and sessions, installs new credentials and increments authority generation. Validator keys, operator responsibilities, reviewer assignments and treasury obligations can have separate lifecycles; automatic removal could undermine consensus availability. Verify each transition and the applicable recovery/continuity policy.

Possible overlap: TN-054; TN-056; TN-057.

Source/evidence: runtime/apply/identity.py#L1258-L1367.

Proposed closure: Verify role-specific transitions and quorum availability, not unconditional role revocation.

### R0-C06 — Stale same-block authority

Block admission adjusts signer nonce but does not visibly reconstruct all preceding authority mutations. The dispatcher rechecks founder expiry and recovery restrictions, so this is not a total absence of apply-time gates. A revoked-key transaction following a revocation in the same block requires signed reproduction and an explicit effective-point rule (transaction order or next block boundary).

Possible overlap: TN-009; TN-013.

Source/evidence: runtime/block_admission.py#L323-L477; runtime/block_replay.py#L690-L770; runtime/apply/identity.py#L547-L591.

Proposed closure: Establish authorized effective boundary and verify signed ordering, leader/follower/helper outcomes.

### R0-C07 — Explicit zero finality falls back to optimistic height

`procedure_height()` accepts positive finalized heights; explicit zero falls back to optimistic height. Phase 5C reported both direct and nested explicit-zero assertion failures (actual 3 instead of 0). Confirm scheduler reachability and preserve genuinely absent-field legacy behavior.

Possible overlap: TN-014; TN-012.

Source/evidence: runtime/constitutional_clock.py#L172-L191.

Proposed closure: Verify explicit zero versus absent finality at procedure and production scheduler boundaries.

### ADV-006 — Placeholder economic policy readiness

Phase 5B R18 reported placeholder policy records producing ready=True; empty state is rejected. This is a predicate failure, not proof that an unauthorized production activation succeeds.

Possible overlap: TN-031; TN-034.

Source/evidence: Phase 5B R18.

Proposed closure: Verify readiness rejects incomplete policies; prove activation path fails closed.

## Recovered experimental observations

The preserved Phase 5B and 5C logs describe source-excerpt/predicate fixtures. The results below were not rerun for this archive. An illustrative assertion must be checked against authorized policy before being treated as a defect.

| Finding | Expected / observed |
|---|---|
| TN-033 | Balanced distribution preserves aggregate 100; debit 50 with credit 40 or 0 accepted and leaves 90 or 50. Production scheduler reachability not proven. |
| TN-037 | Saturated 64-peer store did not admit new peer. Network-wide eclipse not demonstrated. |
| TN-039 | Signed-record fixtures with zero start or expiry accepted. Signature verification was fixture-based. |
| TN-041 | Peer persistence failure not surfaced. |
| TN-050 | Missing timestamp left a helper request window open. |
| TN-052 | Parent/child read-write and write-write conflicts, and slash aliases, were not caught. Opposite writes in the diagnostic gave balances 20 and 10. This is not a proven production merge-order divergence. |
| TN-066 | Quorum 1 observed for a synthetic 10,000-member electorate with 1 basis point; illustrative floor 6,700 is not a newly authorized threshold. |
| TN-071 | Same illustrative tally returned early=False, deadline=True. |
| TN-072 | Multi-option total 80 yielded counted=0 in the inspected direct-only counting function. |
| TN-075 | Initial ±95,000 saturates at ±100,000 after ±20,000 delta, then reverses to ±80,000 rather than original value. |
| TN-078 | Synthetic manifest interval 30,000 overrides committed 20,000; committed slot rejected. Conflicting live-node configuration reachability not established. |
| ADV-006 | Placeholder policy returns ready=True. |
| R0-C07 | Direct and nested zero finalized height return optimistic height 3. |

Positive controls include balanced distribution, rejection of over-credit and overdraw fixtures, maximum issuance cap, duplicate issuance-epoch handling, ordinary peer time/signature controls and off-slot clock rejection. The 5/5 issuance model assumes eligible epochs settle and does not verify actual runtime issuance.

## Remediation and release policy

R0 preserve evidence; R1 consensus foundation; R2 identity and authority; R3 constitutional justice; R4 democratic governance; R5 reputation and economics; R6 infrastructure and product; R7 independent revalidation. Proposed first R1 targets: TN-052, TN-078, R0-C07 and R0-C06. Preserve current behavior before modifying it. All findings require independent validation; a passing CI suite or dormant stronger implementation does not in itself close a defect. Consult the R0 closure contract.

Proposed composite release gates: canonical finality; deterministic execution/replay; credentials; human uniqueness; reputation correction; justice/appeals; governance/ballots; treasury/economic isolation; private evidence/media security; peer discovery; persistence/recovery; helper/serial equivalence; frontend acceptance; independent adversarial review; reproducible deployment and authorization. No composite gate was formally cleared by this audit.

## Related browser acceptance finding (not part of TN register)

F-002 — `invalid_poh_journal_entry` during asynchronous PoH evidence submission. Earlier acceptance report describes same-origin proxy configuration as an empty node address rejected by the journal before upload. Clean install, README verification and observer frontend access passed; recording/review reached; encrypted submission failed. Exact baseline and current resolution not independently established in this archive. Keep separate from 81 TN entries; evaluate possible overlap with TN-058 and TN-059 only after source evidence is recovered. This contextual observation does not establish IPFS or blockchain failure.

## Limitations

Original TN-040 description, complete INV-001–INV-060 text, original full numbered narratives and proof records, original harnesses and remaining test records could not be recovered. Prior R0 phase allocations/acceptance objectives are proposals. Public testnet verdict remains NO-GO.
