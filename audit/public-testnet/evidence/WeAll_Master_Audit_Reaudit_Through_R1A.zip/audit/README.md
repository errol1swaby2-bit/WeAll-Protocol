# WeAll Public Testnet Audit — cumulative findings archive

**Cutoff:** R0 (November 20, 2026). **Frozen baseline:** `6d3d69234415d294936d99e819367cff589ced3d`. [Baseline commit](https://github.com/errol1swaby2-bit/WeAll-Protocol/commit/6d3d69234415d294936d99e819367cff589ced3d).

**Release verdict: NO-GO for public participatory testnet.** The audit is not a certification. This archive consolidates available records and does not change the repository, execute new tests, or authorize policy activation.

## Start here
- `ALL_FINDINGS.md`: human-readable consolidated docket, every numbered entry, eight separately tracked entries, detailed experimental observations and next steps.
- `EVIDENCE_INDEX.md`: evidence sources, provenance, missing material and reconciliation notes.
- `r0/master_register.tsv`: machine-readable master register with acceptance objectives.
- `r0/candidate_register.tsv`: separately tracked issues, overlap hypotheses and source locators.
- `r0/evidence/`: recovered Phase 5B/5C result text (not original raw files).
- `r0/README.md` and `r0/SHA256SUMS`: prior R0 package preserved byte-for-byte.
- `SHA256SUMS`: integrity digests for this archive's individual payload files.

## Coverage
81 numbered entries (21 P0, 60 P1; 80 recovered labels and reserved TN-040), eight additional tracking entries including ADV-006, and zero formal closures. Previously reported 167 checks (119 pass, 48 fail) are not fully reconciled. Saved source-level records cover 53 checks (33 pass, 20 fail), plus a separate five-check mathematical model. The 60-invariant register, original full narratives, raw harnesses and remaining logs have not been fully recovered. No missing record is invented. Earlier unrelated audit baselines (including A01–A20) are excluded. The separate F-002 browser acceptance issue is documented as contextual evidence, not counted under TN IDs.
