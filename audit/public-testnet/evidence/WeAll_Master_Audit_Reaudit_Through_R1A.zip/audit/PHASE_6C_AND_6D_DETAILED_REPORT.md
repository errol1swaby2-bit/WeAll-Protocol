# Phase 6C — Consolidation and severity reassessment

Baseline `6d3d69234415d294936d99e819367cff589ced3d`; strictly read-only.

Provenance: plain-text rendering/reconstruction of the reports visible in the current conversation. All numerical values and substantive observations below are carried forward from those reports. Interactive graphics are rendered as prose or tables. For the original numbered register and all titles, see ALL_FINDINGS.md and r0/master_register.tsv; no titles have been discarded. This is not a newly executed audit.

## 1. Objective and cumulative baseline

The objective is to distinguish individual implementation defects from systemic architectural weaknesses and determine which constitute genuine public testnet deployment blockers. A blockchain can achieve deterministic consensus while consistently executing constitutionally unauthorized decisions. WeAll must protect against both computational and institutional failure.

81 provisional findings; 60 protocol invariants; 21 P0 and 60 P1; 167 previously reported experimental checks, 119 passed (71.3%) and 48 failed (28.7%); zero resolved. These are historical totals, not independently verified anew. Phase 5B and 5C experimental records were recovered and production source files were reopened at the exact audit baseline. The complete itemized register was not initially recoverable; no revised finding totals or premature closures were invented.

## 2. Revised severity and evidence methodology

| Severity | Classification criteria |
|---|---|
| P0 | Consensus failure, unauthorized institutional authority, irreversible state corruption or catastrophic network failure |
| P1 | Material security, constitutional, availability or integrity failure |
| P2 | Contained failure with limited consequences and a credible recovery mechanism |
| P3 | Maintainability, diagnostics, documentation or minor operational deficiencies |

| Evidence level | Description |
|---|---|
| E0 | Architectural hypothesis |
| E1 | Static source confirmation |
| E2 | Executable function-level reproduction |
| E3 | Production transaction-path reproduction |
| E4 | Independent multinode reproduction |

A critical architectural defect supported by E1 evidence warrants investigation before deployment but must not be described as an E4-confirmed exploit. An implemented safeguard is not an operational safeguard until its activation and enforcement are established.

## 3. Consolidated architectural failure families

The following ten categories are remediation families, not replacements for the 81 findings. Identity (PoH and recovery), reputation (eligibility and sanctions), governance (electorates and voting), justice (jurors and disputes), treasury and consensus all depend on compatible cross-domain authority enforcement.

| Family | Architectural weakness | Potential severity |
|---|---|---|
| CF-01 | Fragmented authority evaluation | P0 |
| CF-02 | Stale transaction authorization | P0 |
| CF-03 | Constitutional procedure bypass | P0 |
| CF-04 | Consensus and finality inconsistency | P0 |
| CF-05 | Helper execution and serial equivalence | P0 |
| CF-06 | Network trust and peer discovery | P0 |
| CF-07 | Monetary conservation and activation | P0 |
| CF-08 | Reputation accountability and reversibility | P0–P1 |
| CF-09 | Persistence and operational recovery | P0–P1 |
| CF-10 | Deployment configuration and assurance | P0–P1 |

## 4. CF-01 — Fragmented authority evaluation

Potential critical deployment blocker. The Genesis Constitution states that service authority must originate from explicit role assignments, elections, eligibility, protocol state or another constitutional process. Multiple representations of authority do not necessarily evaluate the same conditions:

| Responsibility | Authority representation |
|---|---|
| Governance participation | Legacy account PoH tier |
| Effective human verification | Canonical PoH status |
| Reviewer participation | Juror role and lane records |
| Reviewer accountability | Account-level eligibility flags |
| Treasury authority | Signer assignments and authorization predicates |
| Account control | Active cryptographic credentials |

Newly established dependency: group emissary election creation imports `_active_group_member_ids()` from governance and uses it to construct the version-one election electorate. The function reads the legacy PoH tier. Canonical status expiration or suspension may therefore leave a legacy Tier 2 mirror affecting both governance and emissary electorate construction. This should be considered alongside TN-018, subject to comparison with its original definition.

Required correction: canonical, domain-specific authority predicates derived from committed state. Historical snapshots must retain their explicitly specified semantics without permitting obsolete authority to be unintentionally exercised. Evidence: E1, production reachability unverified. Sources: `runtime/poh/state.py:200–279`, `runtime/apply/governance.py:647–735`, `runtime/apply/groups.py:1478–1574`.

## 5. CF-02 — Stale transaction authorization

Potential critical deployment blocker. Domain dispatcher inspection establishes a mitigating protection: certain authorization checks do occur during execution, including post-recovery restrictions and founder authority expiration. The inspected wrappers do not establish complete cryptographic reauthorization against the evolving ledger.

| Boundary | Reassessment |
|---|---|
| Initial signature verification | Implemented |
| Sequential nonce admission | Implemented |
| Atomic state mutation | Implemented |
| Apply-time recovery restriction | Implemented |
| Apply-time founder expiration | Implemented |
| Apply-time signing-key revocation | Not established |

Illustration: key is initially active; transaction 1 revokes it; transaction 2 already signed by that key reaches execution. Under initial-state authorization, potentially accepted; under evolving-state authorization, rejected against updated authority. This assumes transaction-order revocation and is not an executed production reproduction. The intended effective boundary (transaction order versus next block) must first be established, then consistently enforced by leader construction, follower replay and helpers. Sources: `runtime/block_admission.py:323–477`, `runtime/domain_dispatch.py`, `runtime/apply/identity.py:547–591`.

## 6. CF-03 — Constitutional procedure bypass

Related findings: TN-020 automatic bans and severe-sanction procedures; TN-066 insufficient quorum bounds; TN-071 inconsistent governance approval semantics; TN-072 nonbinary vote-counting inconsistency; panel contraction and reviewer accountability candidates. Phase 5B predicates produced different early/deadline outcomes under the same illustrative voting conditions.

The source documents stronger version-two initial panel protection as version gated, with no current governance activation path. Illustrative seven-juror panel: v1 dynamic quorum for remaining eligible 7/6/5/4/3/2/1 is 5/4/4/3/2/2/1; original floor is 5. V2 also requires panel completeness. Legitimate withdrawal must remain possible; quorum protection cannot compel voluntary service. Source: `runtime/apply/dispute.py:837–983`. Quorum alone is not verdict approval.

## 7. CF-04 and CF-05 — Consensus integrity and helpers

Recovered Phase 5C failures: TN-050 missing timestamp leaves request window open; TN-052 ancestor/descendant write conflicts and ancestor-read/descendant-write conflicts not detected, slash aliases not recognized; TN-078 conflicting manifest overrides committed block interval; unnumbered candidate explicit zero finality treated as absent. These were isolated functions and dependency fixtures, not independent production validators.

Helper A writes `accounts/x` with balance 10; helper B writes `accounts/x/balance` with 20. A→B produces 20; B→A produces 10. Even with deterministic production merge ordering, missed conflicts may violate serial equivalence. The helper safety spec requires deterministic partitioning, canonical ordering, deterministic merging and serial equivalence. Production merge-order divergence is not established; closure requires production-bound evidence.

## 8. CF-06 — Network trust and peer discovery

Separate discovery, authenticated peer identity and acceptance of consensus information. Related findings TN-001 unsigned seed registry; TN-002 Cloudflare registry verification; TN-003 observer forwarding; TN-037 peer-store saturation; TN-039 temporal advertisement validation; TN-041 peer persistence failure reporting. Recovered experiments demonstrate saturated store, zero validity-field and error-reporting failures, not network-wide eclipse. Potential chain: untrustworthy discovery → saturation → reduced access to new peers → isolation risk → inability to synchronize independently. Adversarial network testing is necessary.

## 9. CF-07 — Monetary conservation and economic activation

Maximum-supply and duplicate-epoch controls are meaningful, not proof of subsequent economic transaction integrity. Phase 5B distribution results:

| Initial aggregate | Debit | Credit | Result |
|---:|---:|---:|---|
| 100 | 50 | 50 | 100 |
| 100 | 50 | 60 | Rejected |
| 100 | 50 | 40 | 90 |
| 100 | 50 | 0 | 50 |

TN-033 concerns handler-level conservation. Unauthorized scheduler/production reachability remains outstanding. Independent controls required for supply cap, issuance authorization, conservation, treasury authority and constitutional activation. A demonstrably locked or unreachable mechanism may be a conditional deployment blocker, not resolved merely because locked.

## 10. CF-08 — Reputation accountability and reversibility

TN-075: reversing original delta does not necessarily undo actual applied effect under bounds. Example normalized initial 0.95, event +0.2, after clamp 1.0, reverse original delta to 0.8, residual -0.15. Symmetric negative case results in +0.15 residual. Incorrect reversal can prolong exclusion after successful appeal. Required deterministic correction accounting for saturation, intervening events and provenance. Provisional P1 with potential P0 consequences if incorrect state triggers constitutionally unauthorized sanctions.

## 11. CF-09 and CF-10 — Persistence and deployment assurance

| Security boundary | Required evidence |
|---|---|
| Clean installation | Independent fresh-clone deployment |
| Persistent state | Verified crash recovery |
| Consensus history | Cryptographically authenticated finality |
| Public configuration | Consistent canonical network parameters |
| Genesis authority | Verified activation and expiration |
| Frontend | Complete real-user acceptance rehearsals |
| Network participation | Independent discovery and synchronization |
| Recovery | Demonstrated credential and responsibility transitions |

Automated integration success alone cannot establish all deployment requirements.

## 12. Deployment classification and remediation order

Private development network permitted for controlled testing; controlled external rehearsal conditional; public observer not cleared; public participatory testnet NO-GO; mainnet NO-GO. Proposed order: (1) consensus, finality, deterministic execution, (2) cryptographic authority and admission, (3) identity/PoH/eligibility, (4) justice and sanctions, (5) governance/elections, (6) reputation accounting, (7) economics and treasury, (8) networking/persistence/recovery, (9) frontend and deployment assurance, (10) independent adversarial revalidation. This is a proposed dependency order, not authorization to modify the repository.

Phase 6C partial, original register reconciliation pending; zero new executions and zero modifications. NO-GO.

# Phase 6D — Final production-readiness assessment

Baseline unchanged; read-only. Executive assessment: public participatory testnet NO-GO. 81 provisional findings, 60 invariants, 21 P0, 60 P1, ten remediation families, zero closed. WeAll has meaningful implemented consensus, human verification, governance, dispute, reputation and monetary mechanisms. Interactions can still yield unauthorized or inconsistent outcomes.

## Specification authority

Documents referenced in the previous assessment: Genesis Constitution v0.1 (rights and limits), V2 full-scope specification (integrated design), V1.5 implementation evidence map (completeness), reputation matrix plan (integrity and accountability), helper consensus spec (deterministic parallel execution), Master Audit Driver (method). The V2 document was reported marked `V2_0_FIRST_DRAFT_NOT_AUTHORIZED` and aligned to earlier revision `63629d71`; Constitution marked draft for review. No inference of ratification or implementation completeness from a design document alone.

## Findings register reconstruction

80 of 81 labels (98.8%); 21/21 P0 and 59/60 P1 labels. TN-040 remains reserved; title not recovered. Full original evidence narratives are missing for some findings. The entire numbered list and acceptance criteria are preserved in ALL_FINDINGS.md and r0/master_register.tsv. Previously inferred P1 classification must be rechecked against originals. All 21 retain provisional P0 classification, not claims of proven production exploits.

## Experimental reconciliation

167 historical checks, 119 pass and 48 fail. Directly recovered Phase 5B: 14 pass/8 fail (22); Phase 5C: 19 pass/12 fail (31). Together 53 source-level checks and 20 failed assertions. Phase 5B also 5 separate model passes. Failed assertions: TN-033,037,039,041,050,052,066,071,072,075,078, ADV-006, explicit-zero-finality candidate. Exact results in the two saved evidence logs; harnesses now text-extracted separately in this package. Neither the sum of model/source checks nor failures should be treated as counts of unique production exploits.

## Final source-level verification

| Function | Assessment |
|---|---|
| `admit_block_txs()` | nonce sequencing established; evolving signing authority requires further verification |
| `detect_materialized_overlap()` | exact path conflicts but not hierarchical conflicts |
| `procedure_height()` | explicit zero falls back to potentially optimistic height |
| `runtime_block_clock_policy()` | enabled manifest policy takes precedence over committed state |

The four reopened boundaries concern inconsistent authorization, execution and premature constitutional procedure progression. See EVIDENCE_INDEX.md for pinned links and the retrieved Phase 5 records for executable evidence.

## Constitutional compliance assessment

Mappings identify potential noncompliance, not definitive violations of entire articles.

| Article | Relevant concerns |
|---|---|
| I — Constitutional supremacy | Unauthorized governance/execution |
| II — Core rights | Automatic sanctions, privacy, portability |
| III — Anti-domination | Institutional capture and procedural manipulation |
| IV — Direct democracy | Electorate integrity and ballot confidentiality |
| V — Proof-of-Humanity | Uniqueness and verification consistency |
| VI — Roles and reputation | Stale eligibility and reversal |
| VII — Disputes and review | Panel contraction and sanctions |
| VIII — Groups | Membership and authority |
| IX — Governance | Quorum, deliberation, proposals |
| X — Infrastructure | Node neutrality and historical verification |
| XI — Economics | Monetary and treasury integrity |
| XII — Emergency powers | Limits on extraordinary authority |
| XIII — Amendments | Versioning and approval thresholds |

Severe-sanction target requirements reported from V2: ordinary disputes 7 jurors/5 approvals; serious disputes 15/10; constitutional disputes/severe sanctions 25/80%; severe sanctions fresh-panel appeal before enforcement unless expressly waived under DSP-210 conditions. Coordinate automatic-ban and panel-contraction remediation; reputation must not circumvent due process. These are reported target requirements, subject to the applicable authorized specification.

## Systemic risk assessment

Qualitative impact, not measured exploit probability or implementation completeness: critical (5/5) consensus/finality, cryptographic authorization, governance/justice, identity/privacy; high (4/5) parallel execution, networking, reputation, persistence/recovery, economics; elevated (3/5) frontend reliability. Recursive chain: identity inconsistency → institutional eligibility inconsistency → procedural inconsistency → canonical execution → future decisions based on compromised state. Consensus alone cannot prevent this.

## Proposed release gates

| ID | Gate |
|---|---|
| G01 | Canonical consensus and finality |
| G02 | Deterministic execution and replay |
| G03 | Cryptographic authority and credential security |
| G04 | Human uniqueness and verification |
| G05 | Reputation integrity and reversibility |
| G06 | Constitutional justice and appeals |
| G07 | Governance and ballot integrity |
| G08 | Treasury and economic isolation |
| G09 | Private evidence and media security |
| G10 | Independent peer discovery |
| G11 | Persistence and disaster recovery |
| G12 | Helper and serial execution equivalence |
| G13 | Complete frontend acceptance |
| G14 | Independent adversarial review |
| G15 | Reproducible deployment and release authorization |

Zero composite gates formally cleared; individual passing mechanisms do not independently clear a composite gate.

## Proposed remediation program

R0 audit preservation: freeze findings, references, evidence and candidates. R1 consensus foundation: finality, time, deterministic admission/replay/helpers. R2 identity and authority: credentials, eligibility and privacy. R3 constitutional justice: sanction provenance, jurors, accountability and appeals. R4 democratic governance: electorate, quorums, ballots, elections, amendments. R5 reputation/economics: correction, conservation, treasury and activation. R6 infrastructure/product: networking, storage, persistence, recovery, APIs and frontend lifecycle. R7 independent revalidation: full regressions and controlled fresh-install multinode rehearsals. Each phase requires implementation evidence, negative tests, specification mapping and exact-commit validation.

## Final audit status and limitations

Phases 0–6B previously reported done; 6C index reconstructed and 6D assessment delivered but reconciliation incomplete. Original TN-040, complete 60-invariant registry and all 167-check evidence remain unavailable; not all 390 pages of V2 exhaustively reconciled. No new tests or changes in Phase 6D. Recommendations not authorization for protocol changes. The evidence supports coordinated hardening, not proof that wholesale redesign is necessary. Public testnet NO-GO.
