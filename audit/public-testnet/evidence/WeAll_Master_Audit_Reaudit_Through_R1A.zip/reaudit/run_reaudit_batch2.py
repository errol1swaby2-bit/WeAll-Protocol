#!/usr/bin/env python3
"""Fresh R5A/D/E-area checks; real source with explicit dependency substitution."""
from __future__ import annotations
import ast, asyncio, copy, hashlib, hmac, io, json, types, os
from pathlib import Path
from typing import Any, Mapping
import run_reaudit as core
ROOT=core.ROOT
SOURCES={
 'sessions':('runtime/session_keys.py','c7af7a7dfbad8d6e24c9727045dd0920077de143',{'session_key_hash':(13,22,'56c7e415'),'session_record_key':(25,26,'c0d484eb'),'is_hashed_session_key':(29,30,'61d74b1e'),'session_record_for':(33,47,'5ec56ab7'),'store_session_record':(50,56,'98e4eec2'),'revoke_session_record':(59,66,'4ed0d471')}),
 'security':('api/security.py','8cd23bd4f48baafdbd2f46d397293a9de7bd0bd6',{'require_account_session':(139,181,'d9068d64')}),
 'custody':('runtime/apply/identity.py','24154d348c10a3be6b273797ea34a051298f4c03',{'_apply_account_device_revoke':(659,681,'467e0617'),'_apply_account_session_key_issue':(687,745,'c8f9827e'),'_apply_account_session_key_revoke':(748,770,'4a5ed45b')}),
 'recovery_receipt':('runtime/apply/identity.py','24154d348c10a3be6b273797ea34a051298f4c03',{'_apply_account_recovery_receipt':(2122,2159,'cc58bd90')}),
 'recovery_scheduler':('runtime/account_recovery_scheduler.py','3e894f141fbb64b33aceabcc506fc0449124faa4',{'_as_str':(19,23,'aff01937'),'_as_int':(26,30,'c30cc481'),'_panel_commitment':(33,35,'aff8763f'),'_enqueue_receipt':(38,48,'6b8417af'),'schedule_account_recovery_system_txs':(51,176,'c670ea35')}),
 'upload':('api/routes_public_parts/poh.py','1c6dee627098ae7a39f9d4b88d055da5f67242cf',{'_upload_poh_video_evidence':(154,252,'aee971d6')})}

def load(key,**stubs):
    path,sha,expected=SOURCES[key];raw=(ROOT/'source'/f'{key}.py.txt').read_text();doc=ast.parse(raw)
    names={n.name:n for n in doc.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    if set(names)!=set(expected):raise RuntimeError(f'function list mismatch {key}')
    for name,(first,last,digest) in expected.items():
        actual=core.fnv(ast.get_source_segment(raw,names[name]))
        if actual!=digest:raise RuntimeError(f'{key}.{name} {actual} != {digest}')
        print(f'SOURCE OK {path}:{first}-{last} {name} fnv={actual} blob={sha}')
    ns={'Json':dict,'Any':Any,'Mapping':Mapping,'hashlib':hashlib,'json':json,**stubs};exec(compile(raw,str(ROOT/'source'/f'{key}.py.txt'),'exec',flags=0x1000000),ns);return ns

def string(v):return str(v or '').strip()
def integer(v,default=0):
    try:return int(v)
    except (TypeError,ValueError): return default

def main():
    # Unique new identifiers continue the numbering, but not the historical R01–R32 sequence.
    prior=json.loads((ROOT/'evidence'/'fresh_results.json').read_text());core.rows.extend(prior)
    check=core.check
    T=load('sessions',_SESSION_KEY_DOMAIN=b'weall/session-key/v1\x00',SESSION_KEY_HASH_PREFIX='skh:v1:')
    A=load('security',session_record_for=T['session_record_for'])
    C=load('custody',_require_not_banned_or_locked=lambda s,i:s['accounts'][i],_expect_nonce=lambda a,e:a.get('nonce',0)+1,_payload=lambda e:e.payload,_as_str=string,_as_int=integer,ApplyError=core.ApplyError,store_session_record=T['store_session_record'],revoke_session_record=T['revoke_session_record'])
    secret='fixture-only-secret-01'
    def ss(ttl=60,active=True,time=100):
        st={'height':10,'time':time,'accounts':{'@a':{'nonce':0,'devices':{'by_id':{'d1':{'revoked':False}}},'session_keys':{}}}};T['store_session_record'](st['accounts']['@a']['session_keys'],secret,{'active':active,'ttl_s':ttl,'issued_at_ts':100,'device_id':'d1'});return st
    def auth(s,token=secret,account='@a'):
        try:return A['require_account_session'](types.SimpleNamespace(headers={'x-weall-account':account,'x-weall-session-key':token}),s)
        except PermissionError as e:return str(e)
    check('5A-area','TN-053','new session state stores hash, not raw bearer',lambda:secret in json.dumps(ss()),False)
    check('5A-area','SESSION-CONTROL','valid bearer resolves hashed record',lambda:auth(ss()),'@a')
    check('5A-area','SESSION-CONTROL','wrong bearer denied',lambda:auth(ss(),token='wrong'),'session_invalid')
    check('5A-area','SESSION-CONTROL','missing bearer denied',lambda:auth(ss(),token=''),'session_missing')
    check('5A-area','SESSION-CONTROL','wrong account denied',lambda:auth(ss(),account='@b'),'session_invalid')
    check('5A-area','SESSION-CONTROL','revoked bearer denied',lambda:auth(ss(active=False)),'session_revoked')
    check('5A-area','SESSION-CONTROL','before expiration accepted',lambda:auth(ss(time=159)),'@a')
    check('5A-area','SESSION-CONTROL','after expiration denied',lambda:auth(ss(time=161)),'session_expired')
    check('5A-area','SESSION-CONTROL','missing chain time rejects positive TTL',lambda:auth(ss(time=None)),'session_expired')
    check('5A-area','TN-055','zero TTL cannot remain usable indefinitely',lambda:auth(ss(ttl=0,time=10000000)),'session_expired')
    def issue(ttl=None,policy=None):
        st=ss();a=st['accounts']['@a'];a['session_keys']={};a['security_policy']={} if policy is None else {'session_ttl_s':policy};p={'session_key':secret};p.update({} if ttl is None else {'ttl_s':ttl});C['_apply_account_session_key_issue'](st,types.SimpleNamespace(signer='@a',payload=p));return T['session_record_for'](a['session_keys'],secret)['ttl_s']
    check('5A-area','SESSION-CONTROL','policy caps requested TTL',lambda:issue(1000,60),60)
    check('5A-area','SESSION-CONTROL','policy sets omitted TTL',lambda:issue(None,60),60)
    check('5A-area','TN-055','omitted TTL with no policy should acquire finite lifetime',lambda:issue(None,None)>0,True)
    def device_revoke():
        s=ss();C['_apply_account_device_revoke'](s,types.SimpleNamespace(signer='@a',payload={'device_id':'d1'}));return auth(s)
    check('5A-area','TN-054','device revocation invalidates its synthetic associated bearer',device_revoke,'session_revoked','synthetic linked session; production association policy not established')
    def session_revoke():
        s=ss();C['_apply_account_session_key_revoke'](s,types.SimpleNamespace(signer='@a',payload={'session_key':secret}));return auth(s)
    check('5A-area','SESSION-CONTROL','explicit session revocation denies API request',session_revoke,'session_revoked')
    # Recovery scheduler + receipt: real methods with controlled reviewer selection/queue and evidence closure.
    R=core.load('recovery',effective_poh_tier=lambda s,i:s['accounts'][i].get('tier',0),reviewer_lane_active=lambda s,i,l:True,eligible_reviewer_ids=lambda s,l:[],POH_ASYNC_REVIEW_LANE='fixture')
    I=core.load('identity',_ensure=lambda s,k,d:s.setdefault(k,d),ApplyError=core.ApplyError)
    Q=load('recovery_scheduler',select_recovery_reviewers=lambda s,**kw:s.get('fixture_panel',[]),review_counts=R['review_counts'],enqueue_system_tx=lambda s,**kw:s.setdefault('fixture_queue',[]).append(kw))
    H=load('recovery_receipt',_payload=lambda e:e.payload,_as_str=string,_as_int=integer,_find_recovery_request=I['_find_recovery_request'],_append_failed_recovery_attempt=lambda r,**kw:r.setdefault('fixture_failed',[]).append(kw),_current_height=lambda s:s['height'],close_case_evidence=lambda s,**kw:s.setdefault('fixture_closed_evidence',[]).append(kw),ApplyError=core.ApplyError)
    def recovery(method='continuity',status='under_review',reviews=None,deadline=10,panel=None):
        req={'method':method,'status':status,'review_deadline_height':deadline,'panel_size':3,'approval_threshold':2,'reviews':reviews or {}};a={'locked':True,'recovery':{'active_reversal_request_id':'q' if method=='reversal' else None,'requests':{'q':req}}};return {'height':11,'accounts':{'@a':a},'fixture_panel':panel or []},a,req
    def schedule(method,status,*,reviews=None,height=11,panel=None):
        s,a,r=recovery(method,status,reviews,panel=panel);Q['schedule_account_recovery_system_txs'](s,next_height=height);return r['status']
    check('5D-area','RECOVERY-CONTROL','continuity social attestations expire',lambda:schedule('continuity','awaiting_social_attestations'),'expired')
    check('5D-area','TN-080','reversal awaiting social attestations expires',lambda:schedule('reversal','awaiting_social_attestations'),'expired')
    check('5D-area','RECOVERY-CONTROL','under-review reversal expires',lambda:schedule('reversal','under_review'),'expired')
    check('5D-area','RECOVERY-CONTROL','deadline height remains reviewable',lambda:schedule('reversal','under_review',height=10),'under_review')
    check('5D-area','RECOVERY-CONTROL','insufficient panel fails assignment',lambda:schedule('continuity','awaiting_assignment',height=9),'assignment_unavailable')
    check('5D-area','RECOVERY-CONTROL','complete panel assigned',lambda:schedule('continuity','awaiting_assignment',height=9,panel=['@r1','@r2','@r3']),'under_review')
    approve={'@r1':{'decision':'approve'},'@r2':{'decision':'approve'}};reject={'@r1':{'decision':'reject'},'@r2':{'decision':'reject'}}
    check('5D-area','RECOVERY-CONTROL','threshold approval schedules finalization',lambda:schedule('continuity','under_review',height=9,reviews=approve),'approved')
    check('5D-area','RECOVERY-CONTROL','mathematically impossible approval rejects',lambda:schedule('continuity','under_review',height=9,reviews=reject),'rejected')
    def receipt(method,status):
        s,a,r=recovery(method,status);H['_apply_account_recovery_receipt'](s,types.SimpleNamespace(payload={'request_id':'q','status':status}));return (a['locked'],a['recovery']['active_reversal_request_id'],r['status'])
    check('5D-area','RECOVERY-CONTROL','failed continuity receipt unlocks account and records receipt',lambda:receipt('continuity','expired'),(False,None,'receipt_recorded'))
    check('5D-area','TN-057','failed reversal receipt should release lock and active request',lambda:receipt('reversal','rejected'),(False,None,'receipt_recorded'),'synthetic initially locked reversal; alternative unlock policy/path unresolved')
    check('5D-area','TN-057','expired reversal receipt should release lock',lambda:receipt('reversal','expired'),(False,None,'receipt_recorded'),'synthetic initially locked reversal; alternative unlock policy/path unresolved')
    # Encrypted evidence upload: no real file storage, encryption, session auth, or IPFS.
    class ApiError(Exception):
        @classmethod
        def bad_request(cls,*a):return cls(*a)
        @classmethod
        def not_found(cls,*a):return cls(*a)
    class File:
        def __init__(self,data,mime):self.data=data;self.content_type=mime;self.filename='fixture.bin'
        async def read(self,n):return self.data[:n]
    env={'enabled':True,'local':True,'provider_size':8,'cid_valid':True,'principal_ok':True}
    stored=[]
    def principal(*a,**kw):
        if not env['principal_ok']:raise ApiError('auth','denied')
        return '@fixture'
    U=load('upload',_env_bool=lambda key,default:env['enabled'] if key=='enable' else False,_snapshot=lambda r:{},_require_session_principal_for_poh_identity_evidence=principal,_env_int=lambda *a:8,ApiError=ApiError,hmac=hmac,io=io,os=types.SimpleNamespace(getenv=lambda k:'@fixture-provider' if k=='WEALL_EVIDENCE_PROVIDER_ID' else None),_controlled_local_evidence_store_enabled=lambda:env['local'],cidv1_raw_sha256=lambda d:'fixture-cid',_store_encrypted_ciphertext_locally=lambda d,c:stored.append((d,c)),ipfs_add_fileobj=lambda **kw:('fixture-provider-cid',env['provider_size']),validate_ipfs_cid=lambda cid:types.SimpleNamespace(ok=env['cid_valid'],reason='fixture'),PohTier2VideoUploadResponse=lambda **kw:kw,ipfs_gateway_url=lambda c:'fixture-gateway',_is_prod=lambda:False)
    def upload(data=b'12345678',*,mime='application/octet-stream',algorithm='aes-256-gcm',context='sha256:'+'a'*64,commit=None,change=None):
        env.update(enabled=True,local=True,provider_size=8,cid_valid=True,principal_ok=True);env.update(change or {});stored.clear()
        h={'x-weall-evidence-encryption':algorithm,'x-weall-evidence-context-commitment':context,'x-weall-evidence-ciphertext-commitment':commit if commit is not None else 'sha256:'+hashlib.sha256(data).hexdigest()}
        try:return asyncio.run(U['_upload_poh_video_evidence'](request=types.SimpleNamespace(headers=h),file=File(data,mime),enabled_env='enable',max_bytes_env='max',pin_env='pin',default_name='fixture.bin'))
        except ApiError as e:return str(e.args[1])
    def status(**kw):
        v=upload(**kw);return v if isinstance(v,str) else 'ok'
    for label,kw,exp in [('valid commitment and permitted MIME',{},'ok'),('disabled endpoint',{'change':{'enabled':False}},'endpoint_disabled'),('missing session principal (stubbed)',{'change':{'principal_ok':False}},'denied'),('wrong algorithm',{'algorithm':'none'},'client_side_aes_256_gcm_required'),('malformed context hash',{'context':'bad'},'invalid_encryption_context_commitment'),('wrong MIME',{'mime':'video/mp4'},'encrypted_ciphertext_file_required'),('empty object',{'data':b''},'empty_file'),('oversize object',{'data':b'123456789'},'file_too_large (max 8 bytes)'),('mismatched commitment',{'commit':'sha256:'+'b'*64},'ciphertext_commitment_mismatch'),('invalid reported CID',{'change':{'cid_valid':False}},'invalid_cid_from_ipfs:fixture')]:
        check('5E-area','UPLOAD-CONTROL',label,lambda kw=kw:status(**kw),exp,'route function; provider and session dependencies stubbed')
    check('5E-area','TN-058','arbitrary plaintext labeled as AES ciphertext is rejected',lambda:status(data=b'plain'),'rejected','trust-boundary probe; absence of a server proof of encryption is not necessarily a route bug')
    check('5E-area','TN-025','provider-reported size discrepancy rejected instead of accepted',lambda:status(data=b'12345678',change={'local':False,'provider_size':99}),'rejected','synthetic provider discrepancy; actual IPFS behavior and CID validation not tested')
    rows=core.rows[len(prior):];(ROOT/'evidence'/'batch2_results.json').write_text(json.dumps(rows,indent=2)+'\n');(ROOT/'evidence'/'batch2_source_manifest.json').write_text(json.dumps({'baseline':core.BASELINE,'files':SOURCES},indent=2)+'\n')
    for group in sorted({r['group'] for r in rows}):
        rs=[r for r in rows if r['group']==group];print(group,len(rs),'checks',sum(r['status']=='PASS' for r in rs),'pass',sum(r['status']=='FAIL' for r in rs),'fail')
    print('BATCH2 TOTAL',len(rows),'checks',sum(r['status']=='PASS' for r in rows),'pass',sum(r['status']=='FAIL' for r in rows),'fail')

if __name__=='__main__':main()
