# WeAll public testnet audit — source re-audit supplement

**Baseline:** `6d3d69234415d294936d99e819367cff589ced3d`  
**Date:** 2026-11-20  
**Mode:** read-only repository inspection and offline executable diagnostics. No repository mutation, release authorization, implementation change or formal finding closure.

## 1. Purpose and evidence boundaries

The original audit reports 81 numbered findings, 60 provisional invariants, and 167 source/fixture checks (119 pass, 48 fail). The earlier archive preserves 53 individual outcomes and two text-extracted diagnostic harnesses. The remaining original 114 individual check records and historical invariant wording cannot be recovered verbatim. The owner has authorized fresh source re-audit instead of waiting for exported chat history. This supplement is a replacement evidence layer, not a purported recovery of the missing original messages.

All new source excerpts were requested through the repository connection at the frozen commit, not the mutable default branch. Each executable excerpt was independently checked against its FNV-1a checksum computed from a separate pinned source retrieval. The manifests also record Git blob identifiers returned by GitHub. These are excerpt identity checks, not a cryptographic proof of the entire source tree. The full checkout was unavailable because the execution container could not resolve github.com. Neither this report nor any PASS row proves complete production integration, real cryptographic authorization, browser acceptance, persistent state installation or independent-node agreement. Test dependencies are explicitly substituted in the harnesses. No live node, private identity, real bearer secret, or external storage provider was used.

The recovered Phase 5B and 5C text harnesses were executed as Python; both completed with the same historical counts. Their exit code 1 means a found invariant failure, not a failure to execute. The five issuance-model checks are separately tracked. No original record has been rewritten. A failure is a difference from an explicit test expectation, and does not by itself prove a public exploit. Some expectations are proposed safety properties that require policy adjudication. In the replacement invariant registry, CONTROL_PASS means scoped evidence for a predicate, not a production acceptance clearance; CONDITIONAL_FAIL denotes an observed failure under assumptions requiring verification; FAILING_EXCERPT denotes a directly isolated discrepancy; OPEN means the broader requirement is not established. Reconstructed `REINV-*` identifiers are deliberately distinct from historical `INV-*` identifiers. Associations are by family, not a claim that historical individual definitions have been reconstructed exactly.

## 2. Phase 0 refresh: transaction canon and source map

The pinned `Weall-Protocol/generated/tx_index.json` Git blob `f9b521af1fe1a4ca0613b0c955399d119efb73cf` contains 236 transaction types, 236 unique names and 236 unique `id` values. The `by_name` index resolves each name to its position in `tx_types`. The `by_id` index uses numeric keys; the transaction objects carry hexadecimal strings. The by-name linkage passed the inspected comparison. No assertion about numeric alias semantics or index corruption is made without inspecting the index loader and historical compatibility contract. Metadata declares version 1.25.0, append-only law and transaction canon v1.22.2. Its source digest is `d68ee9574c4a9672fe0aacf34eb5bb996138594bbbe26b952f783711dac87d12`.

The committed `audit-metadata/GIT_TRACKED_FILES.txt` in the same revision is a historical manifest, not proof of current file-tree coverage. It listed 2,314 paths, including 280 backend source paths, 995 test paths and 109 `web/src` paths. This differs from the previously reported live audit counts; do not infer that files were removed. A fresh `git ls-tree` could not be run. The generated V2 parameter registry at Git blob `3ab4b73a3b51a37226c494b5692b0e8c15865632` has 215 rows; its presence is not evidence of constitutional activation.

The refreshed module map covers transaction/block admission (`runtime/block_admission.py`), replay (`runtime/block_replay.py`), SYSTEM scheduling and validation (`runtime/system_tx_engine.py`), role and human-status predicates (`runtime/poh/state.py`, `runtime/reviewer_responsibilities.py`), identity/recovery (`runtime/apply/identity.py`, `runtime/recovery_review.py`, `runtime/account_recovery_scheduler.py`), civic eligibility (`runtime/apply/governance.py`), procedure clocks (`runtime/constitutional_clock.py`, `runtime/block_time_admission.py`), economics (`runtime/econ_phase.py`), helper merge (`runtime/helper_merge.py`), sync (`net/state_sync.py`), API session/observer/evidence surfaces (`api/security.py`, `api/routes_public_parts/tx.py`, `api/routes_public_parts/poh.py`), and the retrieved historical peer, governance, economic and helper excerpts. This is targeted indexing; not a fresh exhaustive transaction-to-handler mapping for all 236 types.

## 3. Phase 1 refresh: relevant execution traces

### Account session lifecycle (TN-015/053/054/055)

`_apply_account_session_key_issue` (`runtime/apply/identity.py:687–745`) extracts a bearer string from the envelope, derives a TTL from `ttl_s` or an expiry timestamp, and caps/defaults the TTL only if an account-owned positive session TTL is present. It calls `store_session_record` (`runtime/session_keys.py:50–56`), which stores the hash and format metadata rather than the bearer as a new account-state key. `require_account_session` (`api/security.py:139–181`) resolves the hashed record (with historical raw-key lookup fallback), checks `active is True`, then checks ledger-clock expiration only if TTL is positive. `ACCOUNT_DEVICE_REVOKE` modifies the device row and account nonce; the inspected private API gate does not read device status. `ACCOUNT_SESSION_KEY_REVOKE` separately resolves and marks the session inactive. The full canonical block persistence path for the raw input was not exercised. The stronger historical raw-bearer-history claim remains unclosed.

### Recovery lookup and lifecycle (TN-057/079/080)

`_iter_recovery_requests` traverses accounts and each recovery request mapping; `_find_recovery_request` returns the first matching request ID. `schedule_account_recovery_system_txs` iterates sorted accounts/requests, expires continuity awaiting social attestations, assigns continuity/reversal panels, and resolves under-review requests using approval/rejection thresholds and review deadline. It enqueues SYSTEM finalization or receipt work. `_apply_account_recovery_receipt` then records failures, closes evidence, clears the lock for non-reversal methods, and clears the active reversal request for reversal methods without explicitly clearing `account.locked`. The recovery-open path (identity.py:1914–1989) writes `active_reversal_request_id`, extends restrictions and sets the subject locked. Whether the awaiting-social reversal state can occur with accepted input and whether another authorized unlock route is guaranteed remain open.

### Observer queue and confirmation (TN-062/081)

`_prune_tx_queue_rows` filters expirations, retains old accepted entries under the TTL rule, sorts by age and truncates to the record limit. Only afterward does its byte-budget stage prefer confirmed records for eviction. Under an unresolved-only byte load it drops unresolved records. `_status_from_upstream` reads at most 1 MiB, parses a dictionary, rejects a provided mismatching transaction ID, and coerces the `ok` field by truthiness. It does not itself require a returned transaction ID, committed height or successful receipt. The separate `_prove_already_applied_tx_at_matching_tip` boundary (tx.py:1362–1468) requires a matching ID, confirmed status, `apply_ok is True`, local height/block identity, matching queue confirmation and stable local/remote current commitments. Consequently a permissive parser is not proof of false finality: each caller must be traced before escalation.

### Economic lock and SYSTEM binding (TN-031)

`is_econ_unlocked` calculates eligibility from stored unlock time (or genesis + 90 days) and compares canonical time. `_economics_enabled` coerces the state flag to a bool. `econ_allowed_from_state` combines these conditions. `deny_if_econ_disabled` allows the activation operation after unlock and rejects normal economic operations until enablement. No chain profile check is present in this primitive. Thus profile restrictions must be enforced upstream or downstream by independently authoritative policy. The predicate tests use a synthetic `network_mode` marker; they do not establish the production profile schema or an approved activation path.

`validate_system_tx_queue_binding` requires a queue ID, finds the deterministic entry, checks type, calls single-transaction lineage validation, checks due height, payload due height and phase, and compares signer, parent and canonical payload hash; emitted height must be unset, zero or current. Tests passed these comparison controls with fixture queue and lineage dependencies. The emitter and full signed block verification are not replaced by those stubs. `StateSync._anchor_matches` compares only explicitly populated trusted fields; `verify_response` separately checks header type, chain ID, schema and transaction index, required anchor presence, and snapshot commitment/semantic consistency. The terminal anchor check relative to actual block installation (historical TN-043) is still open.

### Evidence intake (TN-025/058)

`_upload_poh_video_evidence` (`api/routes_public_parts/poh.py:154–252`) applies endpoint enablement and a session principal gate, checks the declared AES-256-GCM algorithm and commitment shape, permits ciphertext MIME types, reads at most configured size + 1, verifies the exact SHA-256 commitment, and sends bytes to a controlled local store or IPFS. It validates the returned CID and reports the provider-returned size. The two negative trust-boundary probes deliberately substitute the provider, principal and CID validation. The route does not prove bytes are authentic AES-GCM ciphertext merely from a header and hash (such a proof is generally unavailable without decryption authority or additional mechanism). Whether raw arbitrary bytes are prohibited by the authorized privacy model and whether provider size must equal payload byte length for the specific IPFS codec are questions, not proven vulnerabilities. TN-025 historically concerns CID/digest declarations; the size probe is adjacent evidence, not the exact original exploit.

## 4. Phase 2 replacement registry

`INVARIANTS.tsv` defines 60 fresh verification targets across the original twelve family counts: consensus (6), deterministic execution (6), authorization (5), identity (5), reputation (5), governance (6), monetary policy (7), helper execution (8), cryptography/privacy (3), persistence (3), networking (3), frontend/API (3). Sources and status are recorded individually. Some rows rely on retained historical source locators and remain OPEN rather than falsely asserting new source verification. The file is an actionable replacement registry, not the lost original individual sentences. It may be used for future remediation after review.

## 5. Phase 3 and 4 replacement scenario analysis

| Scenario | Observed result | Boundary still required |
|---|---|---|
| Duplicate recovery request coordinates | First matching account changes when insertion order reverses (RA-025/026). | Prove duplicate request IDs can be created through admitted transactions; check canonical state serialization and iteration ordering. |
| Unresolved observer work under capacity pressure | New confirmed records displace an older accepted record; accepted-only byte pressure drops older accepted record (RA-034/036). | Rehearse durable client retry/recovery and nonce semantics under actual process and disk limits. |
| Malformed confirmation from upstream | Parser accepts missing ID/receipt or truthy string false (RA-041–043). | Inspect every caller and prove whether an invalid authoritative final status or state import is reachable. |
| Expired or omitted session TTL | Zero-TTL record remains usable at later time; issuance with no policy returns zero (RA-090/093). | Determine permitted session lifetime policy, fully admitted issuance and bypass resistance. |
| Device revoked while session remains active | Synthetic linked session retains access (RA-094); explicit session revoke works (RA-095). | Verify authoritative linkage and device revocation semantics. |
| Reversal request held pending | Awaiting-social reversal has no expiry in tested scheduler branch (RA-097). Failed/expired reversal receipt leaves initially locked account locked (RA-105/106). | Reachability of that state and constitutional lock policy/alternative recovery paths. |
| Local profile restrictions differ | Economic predicate returns true after unlock if enabled with synthetic public-testnet marker, and truthy malformed flag (RA-052/053/058). | Actual profile and policy activation path; reject incompatible typed state and test production route. |
| Hierarchical state overlap | Earlier 5C rerun reproduces ancestor/descendant and alias conflicts missed by exact comparison. | R1A patch is candidate only; planner and real serial equivalence still not validated. |
| Finalized height starts at zero | 5C rerun returns optimistic height for explicit zero and nested zero. | Establish production procedure scheduler's effective finality height at genesis and replay. |
| Conflicting committed clock and local manifest | 5C reproduces local manifest overriding committed clock in fixture. | Verify deployment manifest pinning and independent build/replay at unequal local profiles. |

The recovery-ID experiment is an actual differential observation from two equivalent synthetic record sets with differing insertion order. The other rows identify possible causal chains, not observed node divergence. A false-positive in an isolated guard can be contained by a later fail-closed guard. The full signed transaction path, finality, state persistence and authority cannot be inferred from helper/predicate results alone.

## 6. Phase 5 new checks and historical reruns

| Group | New checks | Passed | Failed |
|---|---:|---:|---:|
| 5A-area (custody/session) | 15 | 12 | 3 |
| 5D-area (recovery/independence) | 37 | 32 | 5 |
| 5E-area (observer/evidence) | 29 | 22 | 7 |
| 5F-area (economics/SYSTEM/sync) | 37 | 34 | 3 |
| **Fresh re-audit** | **118** | **100** | **18** |
| 5B recovered harness rerun | 22 | 14 | 8 |
| 5C recovered harness rerun | 31 | 19 | 12 |
| **Executed in this pass** | **171** | **133** | **38** |

Five separate mathematical model checks passed. Do not add the 171 current checks to the historical 167: 53 are explicit reruns and the 118 fresh checks are new scenarios. Equal or greater quantity than missing historical checks does not imply equivalent scope. Original Phase 5A/D/E/F case identifiers and individual outputs remain unavailable. Their thematic areas are revisited, not every historical assertion. In particular, many frontend, media, governance, real sync installation, baseline readiness, production signature and acceptance concerns are not fully exercised.

The new failures implicate ten numbered topics: TN-025,031,054,055,057,058,062,079,080,081 (not a count of distinct verified exploits). Some rows are direct discrepancies with code; others compare a stronger safety expectation to a synthetic dependency or policy. No new numbered IDs or severity changes are assigned on this basis. The source excerpts, runnable scripts, row-level JSON and text results are included. The recovered 5B/C harnesses remain in `harnesses/` in the parent archive and fresh rerun logs are under `evidence/historical_reruns/`.

## 7. Phase 6 recursion and closure criteria

The cross-domain problem remains inconsistent authority and boundary semantics rather than merely isolated failed predicates. Re-audit of `admit_block_txs` confirms nonce bookkeeping against the initial ledger with a nonce-adjusted admission view; `block_replay` executes sequentially and distinguishes SYSTEM failures from ordinary apply failures. Signed authorization after same-block key revocation must be resolved at the policy-defined effective boundary, not presumed exploitable. Fresh source reads show `effective_poh_tier` gates on status and expiry, while governance's active-membership calculation reads legacy `poh_tier`; production lifecycle/snapshot policy still requires verification. Reviewer responsibility status must be reconciled with sanctions in other role domains. Zero-finality and helper path conflicts remain directly reproduced but not remediated at the audited commit.

The immediate R1A patch remains uncommitted. Before moving to public readiness, prove that the planned R1B planner and helper-merge corrections preserve serial semantics through normal and adversarial execution, then independently test canonical time/finality and signed authority transitions. A finding is closed only after accepted intended policy, negative regressions in a real transaction path, exact-commit CI, and independent-node tests when required. Retain each original finding ID, evidence scope, proposed fix and closure criteria. Additive evidence does not authorize changes to the protocol or constitutional rules.

## 8. Outstanding audit coverage

The historical narrative for some findings remains label-only in the R0 register. The full repository checkout, exhaustive transaction-to-handler mapping, full original scenario IDs, 114 original individual experiment records, 60 exact historic invariant sentences, and independent production-level validation remain unavailable. The newly constructed evidence is useful but not a full equivalent of every lost original report. Complete production validation still requires the checked-out baseline, real dependencies, actual signed envelopes, durable database tests, real IPFS and browser journeys, and independent nodes. No original experimental failures are erased; no PASS result clears a composite release gate. Public participatory testnet: **NO-GO**.
