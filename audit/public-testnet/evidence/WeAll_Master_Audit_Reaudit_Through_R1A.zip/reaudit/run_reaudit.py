#!/usr/bin/env python3
"""Offline re-audit, not historical recovery. No real network or credentials.
Exact pinned function excerpts verified against separately fetched FNV-1a values.
All dependency doubles are explicit below. Run: python3 run_reaudit.py
Exit 0 = execution completed (assertion failures are evidence), 2 = harness fault.
"""
from __future__ import annotations
import ast, copy, hashlib, io, json, types, urllib.parse, urllib.request
from pathlib import Path
from typing import Any, Mapping

ROOT = Path(__file__).resolve().parent
BASELINE = '6d3d69234415d294936d99e819367cff589ced3d'
SOURCES = {
 'econ': ('runtime/econ_phase.py','a08989a534f0af18ec32a5cc256800f42f82d166',{
    'is_econ_unlocked':(65,85,'6c3e962e'),'_economics_enabled':(88,90,'455448bd'),'econ_allowed_from_state':(93,96,'e96578f9'),'deny_if_econ_disabled':(164,196,'a4028852')}),
 'recovery': ('runtime/recovery_review.py','36d6e3061b1268f2d640b77ab8b949d976b93f62',{
    '_as_str':(29,33,'aff01937'),'_as_list':(36,37,'a66e5aed'),'_as_dict':(40,41,'2fd7db29'),'_account':(44,47,'708e7806'),'_identity_set':(50,51,'6e93c482'),'_institution_ids':(54,60,'da023607'),'recovery_conflict_reason':(63,109,'955cde32'),'select_recovery_reviewers':(112,146,'133ae021'),'review_counts':(149,160,'3ded0dc9')}),
 'identity': ('runtime/apply/identity.py','24154d348c10a3be6b273797ea34a051298f4c03',{'_iter_recovery_requests':(893,906,'67c4c3cb'),'_find_recovery_request':(909,914,'d37372b5')}),
 'observer': ('api/routes_public_parts/tx.py','d3e0fb67999b683bbf63ebf096bcbfe5873489b1',{'_tx_queue_created_ms':(503,507,'630a4180'),'_prune_tx_queue_rows':(510,578,'4a9e0482'),'_status_from_upstream':(1121,1155,'e6af364c')}),
 'system': ('runtime/system_tx_engine.py','65e00933cf18abc2e93eb96b37cd6ae7304d20d2',{'_system_payload_hash':(1058,1062,'f01dd19c'),'_expected_emitted_system_env_fields':(1065,1069,'bbcc7c53'),'validate_system_tx_queue_binding':(1072,1127,'bd888126')}),
 'anchor': ('net/state_sync.py','188a5490dfb66f043b6316b204c01f7673a29cb2',{'_anchor_matches':(413,426,'0b175fd8')})
}

def fnv(s):
    h=2166136261
    for b in s.encode('utf-8'): h=((h^b)*16777619)&0xffffffff
    return f'{h:08x}'

def load(key, **stubs):
    path,sha,expected=SOURCES[key]
    raw=(ROOT/'source'/f'{key}.py.txt').read_text()
    doc=ast.parse(raw); names={n.name:n for n in doc.body if isinstance(n,ast.FunctionDef)}
    if set(names)!=set(expected): raise RuntimeError(f'function list mismatch {key}')
    for name,(first,last,digest) in expected.items():
        actual=fnv(ast.get_source_segment(raw,names[name]))
        if actual!=digest: raise RuntimeError(f'{key}.{name} {actual} != {digest}')
        print(f'SOURCE OK {path}:{first}-{last} {name} fnv={actual} blob={sha}')
    ns={'Json':dict,'Any':Any,'Mapping':Mapping,'hashlib':hashlib,'json':json,**stubs}
    exec(compile(raw,str(ROOT/'source'/f'{key}.py.txt'),'exec',flags=0x1000000),ns)
    return ns

class ApplyError(Exception): pass

def result(fn):
    try: return fn()
    except Exception as e: return {'exception':type(e).__name__,'args':list(e.args)}

rows=[]
def check(group, finding, label, fn, expected, scope='isolated source excerpt'):
    actual=result(fn)
    status='PASS' if actual==expected else 'FAIL'
    record=dict(id=f'RA-{len(rows)+1:03}',group=group,finding=finding,label=label,expected=expected,actual=actual,status=status,scope=scope)
    rows.append(record)
    print(f'{record["id"]} {status} {finding}: {label} | actual={actual!r} expected={expected!r}')


def main():
    # 5D-area recovery. PoH and lane status are fixture values, not real checks.
    R=load('recovery',effective_poh_tier=lambda s,i:s['accounts'][i].get('tier',0),reviewer_lane_active=lambda s,i,l:s['accounts'][i].get('lane',False),eligible_reviewer_ids=lambda s,l:s['pool'],POH_ASYNC_REVIEW_LANE='fixture')
    base={'chain_id':'fixture-chain','accounts':{'@target':{'tier':2,'lane':True},'@r':{'tier':2,'lane':True}},'pool':['@r']}
    def reason(r='@r',t='@target',excluded=None,rm=None,tm=None):
        st=copy.deepcopy(base);st['accounts']['@r'].update(rm or {});st['accounts']['@target'].update(tm or {})
        return R['recovery_conflict_reason'](st,reviewer_id=r,target_id=t,excluded_reviewers=excluded)
    for label,kw,exp in [('independent reviewer',{},None),('missing reviewer',{'r':''},'missing_identity'),('self review',{'r':'@target'},'self_review'),('prior reviewer',{'excluded':{'@r'}},'prior_case_reviewer'),('unknown account',{'r':'@missing'},'unknown_account'),('institutional reviewer',{'rm':{'account_type':'institution'}},'institutional_account'),('institutional target',{'tm':{'account_type':'institution'}},'institutional_account'),('banned reviewer',{'rm':{'banned':True}},'reviewer_unavailable'),('locked reviewer',{'rm':{'locked':True}},'reviewer_unavailable'),('low tier',{'rm':{'tier':1}},'reviewer_tier2_required'),('inactive lane',{'rm':{'lane':False}},'reviewer_lane_required'),('shared household',{'rm':{'household_id':'H'},'tm':{'household_id':'H'}},'shared_household'),('reviewer financial dependency',{'rm':{'financial_dependencies':['@target']}},'financial_dependency'),('target financial dependency',{'tm':{'financial_dependencies':['@r']}},'financial_dependency'),('reviewer conflict',{'rm':{'conflicts':['@target']}},'declared_conflict'),('target conflict',{'tm':{'conflicts':['@r']}},'declared_conflict'),('institution overlap',{'rm':{'institution_id':'I'},'tm':{'institutional_affiliations':['I']}},'shared_institution')]:
        check('5D-area','RECOVERY-CONTROL',label,lambda kw=kw:reason(**kw),exp)
    pool=copy.deepcopy(base);pool['accounts']['@s']={'tier':2,'lane':True};pool['pool']=['@r','@s']
    def select(s,n=2,excluded=None):return R['select_recovery_reviewers'](s,request_id='request-1',target_id='@target',panel_size=n,excluded_reviewers=excluded)
    check('5D-area','RECOVERY-CONTROL','full independent panel',lambda:sorted(select(pool)),['@r','@s'])
    check('5D-area','RECOVERY-CONTROL','order-independent scoring',lambda:select({**pool,'pool':['@s','@r']}),select(pool))
    check('5D-area','RECOVERY-CONTROL','insufficient pool fail closed',lambda:select(pool,3),[])
    check('5D-area','RECOVERY-CONTROL','excluded prior reviewer cannot fill panel',lambda:select(pool,2,{'@r'}),[])
    check('5D-area','RECOVERY-CONTROL','only recognized review decisions count',lambda:R['review_counts']({'reviews':{'a':{'decision':'approve'},'b':{'decision':'reject'},'c':{'decision':'unknown'}}}), (1,1,2))
    I=load('identity',_ensure=lambda s,k,d:s.setdefault(k,d),ApplyError=ApplyError)
    def lookup(order):
        st={'accounts':{x:{'recovery':{'requests':{'collision':{'owner':x}}}} for x in order}}
        try: return I['_find_recovery_request'](st,'collision')[0]
        except ApplyError: return 'rejected'
    check('5D-area','TN-079','single request resolves',lambda:lookup(['@a']),'@a')
    check('5D-area','TN-079','unknown request rejects',lambda:lookup([]),'rejected')
    check('5D-area','TN-079','duplicate request id fails closed',lambda:lookup(['@a','@b']),'rejected')
    check('5D-area','TN-079','same records in reverse insertion order resolve identically',lambda:lookup(['@b','@a']),lookup(['@a','@b']))
    # 5E-area queue: configured synthetic limits; fake HTTP response (no transport/auth).
    limits={'WEALL_TX_QUEUE_TTL_MS':60000,'WEALL_TX_QUEUE_CONFIRMED_TTL_MS':60000,'WEALL_TX_QUEUE_MAX_RECORDS':2,'WEALL_TX_QUEUE_MAX_BYTES':65536}
    response={'data':b'{}'}
    fake_url=types.SimpleNamespace(parse=urllib.parse,request=types.SimpleNamespace(Request=urllib.request.Request,urlopen=lambda *a,**k:io.BytesIO(response['data'])))
    O=load('observer',_now_ms=lambda:1000000,_env_int_safe=lambda name,default,**kw:limits.get(name,default),urllib=fake_url,_upstream_operator_headers=lambda:{},_redact_upstream_url=lambda u:'fixture-upstream')
    def record(i,status='pending',created=999000,expires=0,body=''):
        return {'tx_id':i,'upstream_status':status,'created_ms':created,'updated_ms':created,'envelope':{'expires_ms':expires,'body':body}}
    def prune(rs):return [r['tx_id'] for r in O['_prune_tx_queue_rows'](rs)]
    for label,rs,exp in [('invalid/non-id rows dropped',[None,{},record('a')],['a']),('expired pending dropped',[record('a',expires=999999)],[]),('stale confirmed dropped',[record('a','confirmed',900000)],[]),('old pending TTL applied',[record('a','pending',900000)],[]),('old accepted survives TTL',[record('a','accepted',900000)],['a']),('recent confirmed kept',[record('a','confirmed')],['a']),('record cap bounds count',[record('a',created=998000),record('b',created=999000),record('c',created=999500)],['b','c']),('record cap preserves unresolved accepted over newer confirmed',[record('a','accepted',998000),record('b','confirmed',999000),record('c','confirmed',999500)],['a','c']),('byte budget prefers removing confirmed',[record('a','accepted',998000,body='a'*40000),record('b','confirmed',999000,body='b'*40000)],['a']),('byte budget does not silently drop unresolved accepted',[record('a','accepted',998000,body='a'*40000),record('b','accepted',999000,body='b'*40000)],['a','b'])]:
        check('5E-area','TN-062',label,lambda rs=rs:prune(rs),exp)
    def status(payload):
        response['data']=json.dumps(payload).encode();return O['_status_from_upstream']('http://fixture.invalid','tx-a',timeout_s=1)['ok']
    for label,payload,exp in [('matching valid response',{'ok':True,'tx_id':'tx-a','status':'confirmed','height':5,'apply_ok':True},True),('wrong ID',{'ok':True,'tx_id':'tx-b'},False),('list shape',[],False),('negative upstream status',{'ok':False,'tx_id':'tx-a'},False),('confirmed success without ID',{'ok':True,'status':'confirmed','height':5},False),('string false rejected',{'ok':'false','tx_id':'tx-a'},False),('confirmed success without height or receipt',{'ok':True,'tx_id':'tx-a','status':'confirmed'},False)]:
        check('5E-area','TN-081',label,lambda p=payload:status(p),exp,'HTTP parser only; downstream verification not exercised')
    # 5F-area: actual primitive + synthetic profile field. No assumption that profile is activation authority.
    E=load('econ',DEFAULT_LOCK_SECONDS=90*24*60*60)
    def estate(time,flag,mode='mainnet'):return {'time':time,'params':{'economic_unlock_time':100,'economics_enabled':flag,'network_mode':mode}}
    for label,s,exp in [('pre-unlock disabled',estate(99,False),False),('pre-unlock enabled',estate(99,True),False),('at unlock disabled',estate(100,False),False),('at unlock enabled',estate(100,True),True),('post unlock enabled',estate(101,True),True),('missing time',{'params':{'economic_unlock_time':100,'economics_enabled':True}},False),('missing genesis and unlock',{'time':100,'params':{'economics_enabled':True}},False),('malformed time',estate('bad',True),False),('public-testnet mode after unlock should remain locked',estate(101,True,'public_testnet'),False),('malformed truthy string false should deny',estate(101,'false'),False)]:
        check('5F-area','TN-031',label,lambda s=s:E['econ_allowed_from_state'](s),exp,'primitive only; profile field is synthetic, upstream types and launch gates not exercised')
    def gate(st,tx):
        try:E['deny_if_econ_disabled'](st,tx_type=tx);return 'allowed'
        except ValueError:return 'denied'
    for label,s,tx,exp in [('activation before lock ends',estate(99,False),'ECONOMICS_ACTIVATION','denied'),('activation at unlock',estate(100,False),'ECONOMICS_ACTIVATION','allowed'),('transfer without activation',estate(100,False),'BALANCE_TRANSFER','denied'),('transfer enabled',estate(100,True),'BALANCE_TRANSFER','allowed'),('public testnet transfer post unlock',estate(100,True,'public_testnet'),'BALANCE_TRANSFER','denied')]:
        check('5F-area','TN-031',label,lambda s=s,tx=tx:gate(s,tx),exp,'primitive only; production launch matrix not exercised')
    # SYSTEM binding: fixture queue record and lineage; actual comparison/hash function.
    p={'_system_queue_id':'q1','_due_height':10,'amount':5}
    q=types.SimpleNamespace(queue_id='q1',tx_type='SYSTEM_FIXTURE',due_height=10,phase='post',emitted_height=None)
    S=load('system',_as_str=lambda v:str(v or ''),_as_opt_str=lambda v:str(v or ''),SystemQueueItem=types.SimpleNamespace,TxEnvelope=types.SimpleNamespace,_lookup_queue_item=lambda m,id:(m or {}).get(id),_validated_queue_items=lambda st:st['queue'],_single_tx_lineage_shape=lambda *a,**kw:(True,'',None),EPOCH_FINALITY_SINGLE_TX_CHILDREN=(),_system_queue_env_fields=lambda st,it:(p,'SYSTEM','parent'))
    def binding(changes=None, qchanges=None, **kw):
        env=types.SimpleNamespace(**{'system':True,'payload':p.copy(),'tx_type':'SYSTEM_FIXTURE','signer':'SYSTEM','parent':'parent',**(changes or {})});item=types.SimpleNamespace(**{**vars(q),**(qchanges or {})});args={'next_height':10,'phase':'post',**kw};return S['validate_system_tx_queue_binding']({'queue':[item]},None,env,**args)
    for label,changes,qchanges,kw,exp in [('valid',None,None,{},(True,'')),('missing queue ID',{'payload':{}},None,{},(False,'missing_system_queue_id')),('unknown queue ID',{'payload':{**p,'_system_queue_id':'q2'}},None,{},(False,'unknown_system_queue_id')),('wrong type',{'tx_type':'OTHER'},None,{},(False,'system_queue_tx_type_mismatch')),('wrong due height',None,{'due_height':9},{},(False,'system_queue_due_height_mismatch')),('wrong payload due height',{'payload':{**p,'_due_height':9}},None,{},(False,'system_payload_due_height_mismatch')),('wrong phase',None,None,{'phase':'pre'},(False,'system_queue_phase_mismatch')),('wrong signer',{'signer':'@wrong'},None,{},(False,'system_queue_signer_mismatch')),('wrong parent',{'parent':'other'},None,{},(False,'system_queue_parent_mismatch')),('wrong payload hash',{'payload':{**p,'amount':6}},None,{},(False,'system_queue_payload_mismatch')),('wrong emitted height',None,{'emitted_height':9},{},(False,'system_queue_emitted_height_mismatch')),('same emitted height',None,{'emitted_height':10},{},(True,'')),('zero emitted height',None,{'emitted_height':0},{},(True,''))]:
        check('5F-area','SYSTEM-CONTROL',label,lambda c=changes,q=qchanges,k=kw:binding(c,q,**k),exp,'binding function; queue validation and lineage dependencies stubbed')
    # Anchor matching comparator: completeness is deliberately not validated by this function.
    A=load('anchor',_as_str=lambda v:str(v or ''))['_anchor_matches']
    anchor={'height':5,'tip_hash':'tip','state_root':'root','finalized_height':4,'finalized_block_id':'final','snapshot_hash':'snap'}
    check('5F-area','SYNC-CONTROL','all six fields match',lambda:A(None,anchor,anchor.copy()),True)
    for key,val in anchor.items():
        check('5F-area','SYNC-CONTROL',f'mismatched {key}',lambda key=key:A(None,anchor,{**anchor,key:'different'}),False)
    check('5F-area','SYNC-SCOPE','partial pin compares only provided field',lambda:A(None,anchor,{'state_root':'root'}),True)
    check('5F-area','SYNC-SCOPE','empty pin compares no fields; caller must enforce completeness',lambda:A(None,anchor,{}),True)
    (ROOT/'evidence'/'fresh_results.json').write_text(json.dumps(rows,indent=2)+'\n')
    (ROOT/'evidence'/'source_manifest.json').write_text(json.dumps({'baseline':BASELINE,'files':SOURCES},indent=2)+'\n')
    for group in sorted({r['group'] for r in rows}):
        rs=[r for r in rows if r['group']==group];print(group,len(rs),'checks',sum(r['status']=='PASS' for r in rs),'pass',sum(r['status']=='FAIL' for r in rs),'fail')
    print('TOTAL',len(rows),'checks',sum(r['status']=='PASS' for r in rows),'pass',sum(r['status']=='FAIL' for r in rows),'fail')

if __name__=='__main__': main()
