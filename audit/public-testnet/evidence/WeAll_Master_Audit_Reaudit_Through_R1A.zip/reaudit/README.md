# Re-audit supplement — start here

Pinned baseline: `6d3d69234415d294936d99e819367cff589ced3d`. Read `REAUDIT_REPORT.md` first. The parent archive preserves all 41 files from Recovery II. This directory is new evidence, not original historical transcripts.

- `INVARIANTS.tsv`: sixty reconstructed verification targets with separate REINV identifiers, exact or historical source locators, and scoped evidence status.
- `finding_reaudit_crosswalk.tsv`: all 81 existing finding IDs, fresh check mappings and historical reruns; no finding closed.
- `transaction_domain_counts.tsv`: pinned transaction index origin/domain/context counts.
- `source/`: checksum-matched excerpts; none are replacement repository files.
- `run_reaudit.py`, `run_reaudit_batch2.py`: offline diagnostic scripts; Python 3.10+; no external network or package dependencies. Run the first before the second from this directory. Both report all assertions, including failures, and write evidence; zero process exit is not a PASS verdict.
- `evidence/`: original newly generated logs, JSON, TSV, function manifests and the recovered-harness rerun logs. Phase 5B and 5C harnesses are in the parent `harnesses/` directory.

Re-audit counts: 118 fresh checks (100 passed, 18 failed), 53 repeated historical source checks (33 passed, 20 failed), plus five separate model controls. Do not merge these with 167 historic checks. Full production checkout and independent-node integration not available. Some stronger test expectations represent proposed policy and provider trust assumptions. The prior archive preserves the original counts, gaps, and R1A candidate; no repository changes.

The strongest currently verified boundary is isolated source-excerpt behavior, not production exploitation or formal closure.
