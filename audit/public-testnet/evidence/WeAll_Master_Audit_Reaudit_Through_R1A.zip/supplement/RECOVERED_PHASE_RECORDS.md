# Recovered phase records — November 20, 2026

Baseline: `6d3d69234415d294936d99e819367cff589ced3d`.

These records are **history retrieval summaries**, not verbatim chat transcripts. They supplement the earlier expanded archive; they do not replace previous source artifacts. No new executable tests were conducted. All timestamps below are UTC. Unavailable wording, individual test identities and source citations remain unavailable, rather than being inferred.

## Phase 0 and Phase 1

Original audit conversation identified by the history service as “WeAll Public Testnet Audit” / “WeAll Public Testnet Readiness Audit.” Initial report Nov 19 21:28:53; later Phase 1A–F report material around 21:47:09. Previously recovered Phase 0 index: 2,873 tracked files; 236 transaction types; 295 backend files; 1,170 tests; 143 frontend files; 125 deployment/release files. Phase 0–1F summaries remain in `audit/EARLY_PHASES_RECOVERED_HISTORY.md`.

### Phase 1G — peer networking, distributed synchronization and node security

Original numbered report located in history at Nov 19 23:16:05. Recovered titles: TN-037 Peer discovery saturation; TN-038 Multi-hop peer discovery failure; TN-039 Peer-address expiration; TN-040 Network-loop resource exhaustion; TN-041 Silent peer persistence failures. These titles are retrieved history summaries and may differ in punctuation from the original. TN-040's mechanism is documented separately and newly checked against pinned source in `TN-040.md`.

## Phase 2 — invariant extraction

Original report located at Nov 20 01:30:22. The twelve families and identifier ranges are recovered in `invariant_family_index.tsv`. All sixty were provisional verification targets, not canonical transaction IDs and not individually cleared. The original 60 invariant sentences and corresponding source mappings did not return in the history query.

## Phases 3 and 4

Adversarial and divergence analysis were previously reported, but searches did not recover the original scenario catalog, per-scenario identifiers, complete traces or full report prose. ADV-006 is referenced by the preserved Phase 5B log. Do not treat earlier October audits as equivalent to this exact November revision.

## Phase 5 — experimental reproduction

Counts are reconciled in `phase5_accounting.tsv`. This accounting is based on two directly retrieved result texts (5B, 5C) and four retrieved historical summaries (5A, 5D, 5E, 5F). The 5B mathematical model's five passing checks are separate from the 167 reported source/fixture checks. 53 individual check outcomes are available in the two stored logs; detailed individual outcomes for the remaining 114 are not available. Not all checks used real production dependencies. None of these counts establish a number of production exploits.

### Phase 5A

10 checks; six pass, four fail. The original check-by-check R01–R10 result text, harness and individual TN mapping remain unavailable. These totals were historically reported in the R0 discussion, not directly observed here.

### Phase 5B and 5C

Original result texts and text-extracted harnesses are preserved in `audit/r0/evidence/` and `harnesses/` respectively. Phase 5B: 22 source-level checks (14 pass, 8 fail), plus five separate mathematical model checks. Phase 5C: 31 checks (19 pass, 12 fail). Original raw harness bytes were not recovered. No reruns in this preservation turn.

### Phase 5D — recovered historical report details

Original report timestamp: Nov 20 03:59:38. 32 checks (24 pass, 8 fail). Referenced findings TN-057, TN-079 and TN-080. Reviewer-independence controls 13/13 passed. Reported method: five checksum-matched source excerpts and synthetic fixtures. Production reachability, human uniqueness and end-to-end dispute adjudication unverified. Individual check identities and outputs not recovered; the 13 controls are reported within the phase, not added to counts.

### Phase 5E — recovered historical report details

Original report timestamp: Nov 20 16:24:45. 42 checks (28 pass, 14 fail). Referenced findings TN-061, TN-060, TN-065, TN-062, TN-003, TN-081, TN-058, TN-025 and TN-030. Evidence upload controls 6/7 passed. Synthetic isolated testing; browser journey, deletion, interrupted recovery and deployment boundaries remained unverified. Individual outcomes and raw harness not recovered.

### Phase 5F — recovered historical report details

Original report timestamp: Nov 20 16:38:16. 30 checks (28 pass, 2 fail). TN-031 reportedly reproduced at predicate level: public-testnet economic lock fails after unlock with economics enabled. SYSTEM binding controls reportedly 10/10 passed; bindings included queue ID, type, height, phase, signer, parent and payload hash. Follower checks required SYSTEM ordering/presence. Trusted-anchor comparisons reportedly six passes and reject mismatched roots/finalized identifiers; synchronization applies blocks before terminal anchor validation (TN-043 concern from earlier archive). These are in-memory synthetic fixtures; no production exploit, unauthorized issuance or conflicting finality demonstrated. Individual failed check descriptions and original logs not recovered.

## Phase 6A — reverse authority tracing

Historical report located Nov 20 16:44:31. The available history summary identifies TN-020 automatic reputation-floor bans potentially bypassing severe-sanction safeguards (P0, reported INV-023/025/028/033 links); legacy identity ACCOUNT_BAN bypass not canonically routed; dispute inline account/eligibility mutations differing from ordinary handlers; TN-071 governance execution trusting scheduler-supplied approval fields; slashing proposal/vote overwrite and threshold-reconstruction concerns remained provisional. This is an incomplete summary, not the original execution trace, and not a new source-level verification.

## Phase 6B, 6C, 6D, R0, R1A

Earlier archive reports and candidate patch are unchanged. R1A remains uncommitted and independently unvalidated at full production path. No finding is formally closed by this supplemental preservation work.
