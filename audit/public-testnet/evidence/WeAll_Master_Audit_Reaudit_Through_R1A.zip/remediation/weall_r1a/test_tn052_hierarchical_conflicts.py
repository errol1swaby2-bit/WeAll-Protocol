from __future__ import annotations

from types import SimpleNamespace

import pytest

from weall.runtime.helper_merge import HelperDeltaOp, detect_materialized_overlap


def _lane(lane_id, *, reads=(), writes=(), ops=()):
    return SimpleNamespace(
        cert=SimpleNamespace(lane_id=lane_id),
        read_set=tuple(reads),
        write_set=tuple(writes),
        delta_ops=tuple(ops),
    )


@pytest.mark.parametrize(
    ("left_reads", "left_writes", "right_reads", "right_writes", "expected"),
    [
        ((), ("accounts/x",), (), ("accounts/x",), True),
        ((), ("accounts/x",), (), ("accounts/x/balance",), True),
        ((), ("accounts/x/balance",), (), ("accounts/x",), True),
        (("accounts/x",), (), (), ("accounts/x/balance",), True),
        ((), ("accounts/x",), ("accounts/x/balance",), (), True),
        (("accounts/x/balance",), (), (), ("accounts/x",), True),
        ((), ("accounts/x/balance",), ("accounts/x",), (), True),
        ((), ("accounts/x",), (), ("/accounts//x/",), True),
        ((), ("accounts/x",), (), ("accounts/xy",), False),
        ((), ("accounts/x/a",), (), ("accounts/x/b",), False),
        (("accounts/x",), (), ("accounts/x/balance",), (), False),
        ((), ("content:post:1",), (), ("content:post:10",), False),
        ((), ("accounts/X",), (), ("accounts/x",), False),
        ((), ("/",), (), ("accounts/x",), True),
    ],
)
def test_tn052_component_conflicts(left_reads, left_writes, right_reads, right_writes, expected):
    left = _lane("a", reads=left_reads, writes=left_writes)
    right = _lane("b", reads=right_reads, writes=right_writes)
    forward = detect_materialized_overlap([left, right])
    backward = detect_materialized_overlap([right, left])
    assert forward[0] is expected
    assert backward == forward


def test_tn052_namespace_relative_and_legacy_delta_alias():
    left = _lane("a", writes=("content:post:1",), ops=(HelperDeltaOp("set", "namespaced/content:post:1", {}),))
    right = _lane("b", writes=("/namespaced/content:post:1",), ops=(HelperDeltaOp("delete", "/namespaced/content:post:1"),))
    assert detect_materialized_overlap([left, right])[0]


def test_tn052_same_lane_is_not_cross_lane_conflict():
    lane = _lane("a", reads=("accounts/x",), writes=("accounts/x/balance", "accounts/x"))
    assert detect_materialized_overlap([lane]) == (False, "")


def test_tn052_multiple_readers_then_writer():
    lanes = [_lane("a", reads=("accounts/x/a",)), _lane("b", reads=("accounts/x/b",)), _lane("c", writes=("accounts/x",))]
    assert detect_materialized_overlap(lanes)[0]
