#!/usr/bin/env python3
"""Apply R1A to a real Git checkout after verifying both baseline blobs."""
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
files = {
    "Weall-Protocol/src/weall/runtime/helper_merge.py": "176ac7c6dd37beccf30f78290a681897bc06079b",
    "Weall-Protocol/tests/test_helper_merge.py": "3ca814736bf4cd95fc1fb0ccf0872a53c884396f",
}
for name, expected in files.items():
    actual = subprocess.check_output(["git", "hash-object", str(root / name)], text=True).strip()
    if actual != expected:
        raise SystemExit(f"Baseline blob mismatch: {name}: {actual} != {expected}")
new_test = root / "Weall-Protocol/tests/test_tn052_hierarchical_conflicts.py"
if new_test.exists():
    raise SystemExit(f"Refusing to overwrite {new_test}")
patch = BASE / "TN-052.patch"
subprocess.run(["git", "-C", str(root), "apply", "--check", str(patch)], check=True)
subprocess.run(["git", "-C", str(root), "apply", str(patch)], check=True)
with (root / "Weall-Protocol/tests/test_helper_merge.py").open("a", encoding="utf-8") as handle:
    handle.write((BASE / "integration_append.py.txt").read_text())
new_test.write_bytes((BASE / "test_tn052_hierarchical_conflicts.py").read_bytes())
print("R1A patch and tests applied. No commit or push performed.")
