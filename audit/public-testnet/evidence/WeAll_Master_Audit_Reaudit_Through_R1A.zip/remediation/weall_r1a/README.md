# R1A — TN-052 hierarchical helper conflicts

Baseline: `6d3d69234415d294936d99e819367cff589ced3d`.
Status: **candidate patch prepared; isolated validation passed; production validation and closure pending**.

## Source and scope

The pinned `Weall-Protocol/src/weall/runtime/helper_merge.py` (Git blob `176ac7c6dd37beccf30f78290a681897bc06079b`) compares exact access strings at lines 243–263, but `_set_path` and `_delete_path` interpret slash-delimited components and ignore empty segments. The merge already returns the untouched base state and serializes all expected lanes when overlap is detected. The patch changes only conflict detection: exact/ancestor/descendant relationships, slash aliases, actual delta paths, and deterministic lane traversal. It preserves case, treats colon as an ordinary component character, does not mutate certificate/hash encodings, and uses the existing fallback. Comparing actual and declared write paths conservatively can serialize otherwise independent lanes. The prefix index avoids all-pairs comparisons, but pathological depth/input-size resource bounds have not been measured.

Source: https://github.com/errol1swaby2-bit/WeAll-Protocol/blob/6d3d69234415d294936d99e819367cff589ced3d/Weall-Protocol/src/weall/runtime/helper_merge.py#L243-L277

The pinned existing test module blob is `3ca814736bf4cd95fc1fb0ccf0872a53c884396f`. The installer verifies both files against their Git blob identifiers before writing. Apply to a clean dedicated branch, not to a running deployment. This is not a protocol activation or a consensus compatibility authorization. Historical replay and mixed-version compatibility require review before a network upgrade.

## Apply and validate

From the repository root, with the ZIP extracted outside or inside the checkout:

```sh
git status --short
git switch -c remediation/r1a-tn052
python /path/to/weall_r1a/apply_r1a.py "$PWD"
git diff --check
git status --short
cd Weall-Protocol
PYTHONPATH=src python -m pytest -q tests/test_helper_merge.py tests/test_tn052_hierarchical_conflicts.py tests/test_helper_materialized_merge_restart.py
```

Use the project's established Python environment and dependencies. The installer declines modified/nonmatching source blobs or an existing new test file, and invokes `git apply --check` first. Review the diff and appended test before committing. The installer does not commit or push. The integration regression uses the repository's existing certificate fixtures (not authenticated live helpers). If an installation step fails after the patch has been applied, inspect the working tree before retrying.

## Evidence

- Baseline isolated detector: 7 passed, 10 failed.
- Proposed isolated detector: 17 passed, 0 failed.
- Proposed detector: 400 reference comparisons across pairs of ten path strings and read/write modes, with both input permutations checked per comparison.
- Patch context/syntax checked against a reconstructed source excerpt, not a full Git checkout.
- The original and modified detector excerpts are supplied as `.py.txt`; they are not complete production modules. `run_isolated.py` uses minimal stand-in lane and delta types and imports neither real certificates nor production execution. Re-run using `python run_isolated.py before` (expected nonzero) or `python run_isolated.py after` (expected zero), with pytest installed.
- Full production tests were not executed: direct Git network access from the execution environment could not resolve github.com; source was read through an authenticated repository connector. The proposed integration test is unexecuted.

## Required next evidence

1. Verify the original integration regression fails on the pinned baseline and passes with the candidate; verify the positive disjoint-lane cases, hash commitments and restart tests.
2. Investigate the planner's separate exact-string `_access_conflicts` predicate in `parallel_execution.py` and any earlier or alternative conflict checks. This patch addresses the final materialized merge detector, not every planner/executor path.
3. Confirm that real signed helpers cannot bypass the fallback, that missing/invalid lanes cannot create conflicting partial execution, and that the caller executes the correct canonical serial transaction order. Exercise namespace-relative vs legacy mapping, same-lane duplicate/overlapping delta paths, implicit parent creation and state-shape invariants. These related concerns are not closed by this patch.
4. Compare full state roots, receipts, transaction order and replay outcomes under serial execution, helper success, helper conflict/fallback, timeout and restart; execute independently on multiple nodes.
5. Run exact-head CI, review migration/replay safety and record the patch commit and independent acceptance. Keep TN-052 OPEN until the R0 closure contract is satisfied. No other finding is changed.
