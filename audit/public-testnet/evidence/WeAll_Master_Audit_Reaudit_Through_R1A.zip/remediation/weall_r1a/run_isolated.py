#!/usr/bin/env python3
"""Exercise retrieved detector source with minimal fixture types, not production imports."""
from pathlib import Path
import sys
import types
from dataclasses import dataclass
from itertools import product
from types import SimpleNamespace
import pytest

base = Path(__file__).resolve().parent
variant = sys.argv[1] if len(sys.argv) > 1 else 'after'
if variant not in {'before', 'after'}:
    raise SystemExit('use before or after')
module = types.ModuleType('weall.runtime.helper_merge')
@dataclass
class HelperDeltaOp:
    op: str
    path: str
    value: object = None
module.__dict__.update(MaterializedLaneResult=SimpleNamespace, HelperDeltaOp=HelperDeltaOp)
exec(compile((base / f'detector_{variant}.py.txt').read_text(), f'detector_{variant}', 'exec'), module.__dict__)
sys.modules['weall'] = types.ModuleType('weall')
sys.modules['weall.runtime'] = types.ModuleType('weall.runtime')
sys.modules[module.__name__] = module
code = pytest.main(['-q', '-p', 'no:cacheprovider', str(base / 'test_tn052_hierarchical_conflicts.py')])
if variant == 'before':
    raise SystemExit(code)
if code:
    raise SystemExit(code)
paths = ['a', 'a/b', 'a/b/c', 'a/bc', 'ab', 'a//b', '/a/b/', 'a/B', 'a:b', 'z']
def norm(p):
    return tuple(part for part in p.split('/') if part)
def overlap(a,b):
    a,b=norm(a),norm(b)
    return a[:len(b)] == b or b[:len(a)] == a

def lane(i,p,mode):
    return SimpleNamespace(cert=SimpleNamespace(lane_id=i), read_set=(p,) if mode=='r' else (), write_set=(p,) if mode=='w' else (), delta_ops=())
checks=0
for a,b,am,bm in product(paths,paths,'rw','rw'):
    expected = (am=='w' or bm=='w') and overlap(a,b)
    left,right=lane('a',a,am),lane('b',b,bm)
    result=module.detect_materialized_overlap([left,right])
    assert result[0] == expected, (a,b,am,bm,result,expected)
    assert module.detect_materialized_overlap([right,left]) == result
    checks += 1
print(f'{checks} reference comparisons passed (both permutations each); fixture scope only.')
