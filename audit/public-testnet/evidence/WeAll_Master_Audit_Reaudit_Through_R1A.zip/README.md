# WeAll Public Testnet Audit — expanded evidence recovery archive

Frozen audit baseline: `6d3d69234415d294936d99e819367cff589ced3d`. Scope: November 19–20 2026 audit through R0 and R1A. Archive prepared November 20, 2026. No protocol code, configuration or infrastructure was changed in preparing this archive.

**This is the fullest recoverable package from the accessible records, not a complete export of all historical conversations.** It preserves long-form available information instead of replacing it with a numerical summary. Earlier archives are included unchanged. The historical verdict is NO-GO; 81 numbered entries (80 recovered titles), 8 separately tracked entries, 60 reported invariants, 167 reported checks (119/48), zero formally closed. R1A is a candidate correction only.

## Where to start

- `audit/ALL_FINDINGS.md` — original consolidated report through R0; all numbered findings and candidates, proposed closure criteria, evidence and roadmap.
- `audit/PHASE_6B_DETAILED_REPORT.md` — detailed Phase 6B transcription from user-provided report.
- `audit/PHASE_6C_AND_6D_DETAILED_REPORT.md` — detailed plain-text rendering of visible late-phase reports (not byte-exact chat export; interactive elements rendered as text).
- `audit/EARLY_PHASES_RECOVERED_HISTORY.md` — historical summaries of the earlier phases, explicitly not verbatim narratives.
- `audit/EVIDENCE_INDEX.md` — pinned source links and provenance from previous archive; its harness-unavailable statement is superseded by this archive's text-extraction recovery, but original bytes remain unverified.
- `audit/r0/` — original master TSV, candidate TSV, closure contract, result logs and checksums.
- `harnesses/` — both Phase 5B/5C Python harness texts retrieved via indexed text export; original filenames had .py. Kept as .txt because the original raw bytes were not available. No new runs and no claim of original-byte equality.
- `remediation/weall_r1a/` — full R1A patch, isolated tests, original/candidate logs, before/after detector content, integration append, installer, README, checksums. Not committed or production-validated.
- `prior_archives/` — the three unchanged earlier ZIP packages for archival provenance.
- `reference/Master-Audit-Driver.txt` — original audit methodology (reference, not findings).
- `INVENTORY.tsv` and `SHA256SUMS` — archive file inventory and integrity manifest.

## What remains missing

Original complete transcripts of Phase 0, 1A onward, 2, 3, 4, 5A, 5B/5C report prose, 5D–5F, 6A; complete original 60-invariant list; TN-040 description/evidence; most full original per-finding narratives and source traces; complete 167-check outputs (only Phase 5B/5C original result text recovered, plus later R1A separate evidence); raw original bytes of Phase 5B/5C harnesses. History retrieval returned summaries instead of those transcripts. No invented findings or invariant definitions were added. Older audits on different commits are not included or presented as November baseline evidence.

To make a complete archive, supply the original audit conversation export (or the full copied conversations and missing attachments). Preserve original messages, links, code blocks and tool output when available, then add as a separate immutable transcript collection without replacing the existing files. SHA-256 verifies the archive contents, not their factual accuracy or source authenticity.
